import copy
import math

# --- MOTEUR DE RÈGLES (Basé sur tes spécifications) ---

DIRECTIONS = [
    (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1)
]

VALID_HEXES = set()
VALID_HEXES.update([(0, 4)])
VALID_HEXES.update([(1, r) for r in range(2, 5)])
VALID_HEXES.update([(2, r) for r in range(1, 6)])
for q in range(3, 7):
    VALID_HEXES.update([(q, r) for r in range(0, 7)])

def hex_distance(q1, r1, q2, r2):
    """Calcule la distance entre deux cases sur une grille hexagonale axiale."""
    return (abs(q1 - q2) + abs(q1 + r1 - q2 - r2) + abs(r1 - r2)) // 2

class GameState:
    def __init__(self):
        self.board = {}
        # Pour simplifier la simulation dans un arbre, on considère chaque action 
        # d'une pièce comme un "ply" (demi-tour).
        self.current_team = 'ally'
        self.pieces_moved_this_turn = set()

    def is_valid_hex(self, q, r):
        return (q, r) in VALID_HEXES

    def get_neighbors(self, q, r):
        return [(q+dq, r+dr) for dq, dr in DIRECTIONS if self.is_valid_hex(q+dq, r+dr)]

    def get_visible_pieces(self, q, r):
        visible = []
        for dq, dr in DIRECTIONS:
            cq, cr = q + dq, r + dr
            dist = 1
            while self.is_valid_hex(cq, cr):
                if (cq, cr) in self.board:
                    visible.append({
                        'pos': (cq, cr), 
                        'piece': self.board[(cq, cr)], 
                        'dir': (dq, dr), 
                        'dist': dist
                    })
                    break
                cq += dq
                cr += dr
                dist += 1
        return visible

    def can_be_moved_by_enemy_skill(self, pos, team):
        if self.board[pos]['name'] == 'pro':
            return False
        for n in self.get_neighbors(pos[0], pos[1]):
            if n in self.board and self.board[n]['team'] == team and self.board[n]['name'] == 'pro':
                return False
        return True

    def check_victory(self):
        for (q, r), piece in self.board.items():
            if piece['name'] == 'lea':
                team = piece['team']
                opposing_team = 'enemy' if team == 'ally' else 'ally'
                
                neighbors = self.get_neighbors(q, r)
                
                enemy_count = 0
                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opposing_team:
                        enemy_count += 1
                        if self.board[n]['name'] == 'ass':
                            enemy_count += 10
                        if self.board[n]['name'] in ['our', 'arc']:
                            enemy_count -= 1
                
                # Vérification de l'arc à exactement 2 cases
                for vis in self.get_visible_pieces(q, r):
                    if vis['dist'] == 2 and vis['piece']['team'] == opposing_team and vis['piece']['name'] == 'arc':
                        enemy_count += 1

                if enemy_count >= 2:
                    return opposing_team

                if len(neighbors) > 0 and all(n in self.board for n in neighbors):
                    return opposing_team
        return None

def generate_moves_for_piece(state, q, r, piece):
    moves = []
    
    moves.append({
        'type': 'pass', 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']} maintient sa position en {(q, r)}"
    })

    neighbors = state.get_neighbors(q, r)
    empty_neighbors = [n for n in neighbors if n not in state.board]
    
    has_viz = any(p['name'] == 'viz' and p['team'] == piece['team'] for p in state.board.values())
    name = piece['name']
    
    # --- DÉPLACEMENTS BASIQUES ---
    for n in empty_neighbors:
        moves.append({
            'type': 'move', 'from': (q, r), 'to': n, 'desc': f"{name} avance furtivement en {n}"
        })
        if name == 'lea' and has_viz:
            for sn in state.get_neighbors(n[0], n[1]):
                if sn not in state.board and sn != (q, r):
                    moves.append({
                        'type': 'move', 'from': (q, r), 'to': sn, 
                        'desc': f"lea (Porté par les vents du viz) bondit vers {sn}"
                    })

    # --- VÉRIFICATION DU geo ---
    if any(n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'geo' for n in neighbors):
        return moves

    # --- COMPÉTENCES ACTIVES ---
    if name == 'cav':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q + dq, r + dr), (q + 2*dq, r + 2*dr)
            if state.is_valid_hex(n1[0], n1[1]) and state.is_valid_hex(n2[0], n2[1]):
                if n1 not in state.board and n2 not in state.board:
                    moves.append({'type': 'skill', 'from': (q, r), 'to': n2, 'desc': f"cav charge violemment en {n2}"})

    elif name == 'gar':
        lea_pos = next((pos for pos, p in state.board.items() if p['name'] == 'lea' and p['team'] == piece['team']), None)
        if lea_pos:
            teleport_hexes = [ln for ln in state.get_neighbors(lea_pos[0], lea_pos[1]) if ln not in state.board or ln == (q, r)]
            for t_hex in teleport_hexes:
                moves.append({'type': 'skill', 'from': (q, r), 'to': t_hex, 'desc': f"gar se téléporte pour protéger le lea en {t_hex}"})
                for final_hex in state.get_neighbors(t_hex[0], t_hex[1]):
                    if (final_hex not in state.board or final_hex == (q, r)) and final_hex != t_hex:
                        moves.append({'type': 'skill', 'from': (q, r), 'to': final_hex, 'desc': f"gar se déploie en {final_hex} après téléportation"})

    elif name == 'tav':
        for n in neighbors:
            if n in state.board and state.board[n]['team'] == piece['team']:
                for tn in [x for x in state.get_neighbors(n[0], n[1]) if x not in state.board and x != (q, r)]:
                    moves.append({'type': 'skill', 'from': (q, r), 'target': n, 'to': tn, 'desc': f"Tavernier bouscule amicalement l'allié en {q};{r} vers {tn}"}) # MODIFIé l'affichage

    elif name == 'acr':
        for n in state.get_neighbors(q, r):
            if n in state.board:
                jump1 = (n[0] + (n[0] - q), n[1] + (n[1] - r))
                if jump1 not in state.board and state.is_valid_hex(jump1[0], jump1[1]):
                    moves.append({'type': 'skill', 'from': (q, r), 'to': jump1, 'desc': f"Acrobate voltige par-dessus l'obstacle jusqu'en {jump1}"})

    elif name == 'cog':
        for n in state.get_neighbors(q, r):
            if n in state.board and state.board[n]['team'] != piece['team']:
                my_neighbors = state.get_neighbors(q, r)
                opposite_hexes = [opp for opp in state.get_neighbors(n[0], n[1]) if opp != (q, r) and opp not in my_neighbors]
                for push_hex in opposite_hexes:
                    if push_hex not in state.board and state.is_valid_hex(push_hex[0], push_hex[1]):
                        moves.append({'type': 'skill', 'from': (q, r), 'to': n, 'push_target': n, 'push_to': push_hex, 'desc': f"Cogneur fracasse l'ennemi vers {push_hex} et prend sa place en {n}"})

    elif name == 'rod':
        for h in VALID_HEXES:
            if h not in state.board:
                if not any(hn in state.board and state.board[hn]['team'] != piece['team'] for hn in state.get_neighbors(h[0], h[1])):
                    moves.append({'type': 'skill', 'from': (q, r), 'to': h, 'desc': f"Rôdeuse se fond dans les ombres et réapparait en {h}"})

    elif name == 'lan':
        for vis in state.get_visible_pieces(q, r):
            t_pos, t_piece, (dq, dr) = vis['pos'], vis['piece'], vis['dir']
            land_q, land_r = t_pos[0] - dq, t_pos[1] - dr
            if (land_q, land_r) != (q, r) and state.is_valid_hex(land_q, land_r) and (land_q, land_r) not in state.board:
                moves.append({'type': 'skill', 'from': (q, r), 'to': (land_q, land_r), 'desc': f"Lance-grappin se tracte tel un prédateur vers {t_pos}"})
                
            pull_q, pull_r = q + dq, r + dr
            if (pull_q, pull_r) != t_pos and state.is_valid_hex(pull_q, pull_r) and (pull_q, pull_r) not in state.board:
                if t_piece['team'] == piece['team'] or state.can_be_moved_by_enemy_skill(t_pos, t_piece['team']):
                    moves.append({'type': 'skill', 'from': (q, r), 'target': t_pos, 'to': (pull_q, pull_r), 'desc': f"Lance-grappin ferre {t_piece['name']} et le ramène en {(pull_q, pull_r)}"})

    elif name == 'ill':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1:
                moves.append({'type': 'swap', 'from': (q, r), 'to': vis['pos'], 'desc': f"Illusionniste altère la réalité et échange de place avec {vis['piece']['name']} en {vis['pos']}"})

    elif name == 'man':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1 and vis['piece']['team'] != piece['team'] and state.can_be_moved_by_enemy_skill(vis['pos'], vis['piece']['team']):
                for tn in state.get_neighbors(vis['pos'][0], vis['pos'][1]):
                    if tn not in state.board:
                        moves.append({'type': 'skill', 'from': (q, r), 'target': vis['pos'], 'to': tn, 'desc': f"Manipulatrice force l'esprit de l'ennemi à marcher vers {tn}"})

    return moves

def apply_move(state, move):
    new_state = copy.deepcopy(state)
    
    if move['type'] == 'pass':
        pass
    elif move['type'] == 'swap':
        p1, p2 = new_state.board.pop(move['from']), new_state.board.pop(move['to'])
        new_state.board[move['to']], new_state.board[move['from']] = p1, p2
    else:
        piece = new_state.board.pop(move['from'])
        if 'push_target' in move:
            target_piece = new_state.board.pop(move['push_target'])
            new_state.board[move['push_to']] = target_piece
            new_state.board[move['to']] = piece
        elif 'target' in move:
            target_piece = new_state.board.pop(move['target'])
            new_state.board[move['to']] = target_piece
            new_state.board[move['from']] = piece
        else:
            new_state.board[move['to']] = piece
            
    # Marquer la pièce comme ayant joué ce tour
    if move['type'] != 'pass' or move['type'] == 'pass': 
        new_state.pieces_moved_this_turn.add(move['to'])

    # Changer de tour de façon simplifiée si tous les persos ont joué (ou approximation pour le min/max)
    ally_count = sum(1 for p in new_state.board.values() if p['team'] == new_state.current_team)
    if len(new_state.pieces_moved_this_turn) >= ally_count:
        new_state.current_team = 'enemy' if new_state.current_team == 'ally' else 'ally'
        new_state.pieces_moved_this_turn.clear()

    return new_state


# --- ALGORITHME DE RÉSOLUTION (BACKTRACKING / MINIMAX) ---

def sort_moves_heuristically(state, moves, maximizing_player):
    """
    Trie les mouvements: avancer (rapproche du lea adverse), 
    côtés (distance égale), reculer (distance augmente).
    """
    target_team = 'enemy' if maximizing_player else 'ally'
    lea_pos = next((pos for pos, p in state.board.items() if p['name'] == 'lea' and p['team'] == target_team), None)
    
    if not lea_pos:
        return moves

    def move_score(move):
        if move['type'] == 'pass':
            return 999 # Passer le tour en dernier
        
        # Position principale impliquée par le mouvement
        main_to_pos = move.get('push_to') or move['to']
        return hex_distance(main_to_pos[0], main_to_pos[1], lea_pos[0], lea_pos[1])

    # Trier par distance croissante (plus c'est bas, plus on "avance" vers le lea)
    return sorted(moves, key=move_score)

def get_all_possible_moves(state, team):
    all_moves = []
    for pos, piece in state.board.items():
        if piece['team'] == team and pos not in state.pieces_moved_this_turn:
            piece_moves = generate_moves_for_piece(state, pos[0], pos[1], piece)
            all_moves.extend(piece_moves)
    return all_moves

def find_winning_sequence(state, depth, maximizing_player):
    """
    Explore l'arbre pour trouver un mat forcé. 
    Retourne (Score, [Liste des coups pour y arriver]).
    Score: 10 si Victoire Ally, -10 si Victoire Enemy, 0 sinon.
    """
    winner = state.check_victory()
    if winner == 'ally':
        return 10 + depth, [] # Préfère gagner plus vite
    elif winner == 'enemy':
        return -10 - depth, []
    if depth == 0:
        return 0, []

    current_team = 'ally' if maximizing_player else 'enemy'
    moves = get_all_possible_moves(state, current_team)
    
    # Heuristique : Avancer d'abord
    moves = sort_moves_heuristically(state, moves, maximizing_player)

    best_sequence = []
    
    if maximizing_player:
        max_eval = -float('inf')
        for move in moves:
            new_state = apply_move(state, move)
            # Continuer avec le joueur courant s'il lui reste des pions à jouer ce tour, sinon passer la main
            next_is_max = (new_state.current_team == 'ally')
            
            eval_score, seq = find_winning_sequence(new_state, depth - 1, next_is_max)
            
            if eval_score > max_eval:
                max_eval = eval_score
                best_sequence = [move] + seq
                if max_eval >= 10: # Si victoire garantie trouvée, on coupe court (Alpha-Beta simplifié)
                    break
        return max_eval, best_sequence
    else:
        min_eval = float('inf')
        for move in moves:
            new_state = apply_move(state, move)
            next_is_max = (new_state.current_team == 'ally')
            
            eval_score, seq = find_winning_sequence(new_state, depth - 1, next_is_max)
            
            if eval_score < min_eval:
                min_eval = eval_score
                best_sequence = [move] + seq
                if min_eval <= -10: 
                    break
        return min_eval, best_sequence

# --- INTERFACE UTILISATEUR & CLI ---

def parse_input(prompt_text, team):
    print(f"\n--- {prompt_text} ---")
    print("Entrez les pions un par un sous la forme 'q,r,Nom'. Tapez 'fin' pour terminer.")
    pieces = []
    while True:
        user_input = input(f"[{team.upper()}] Pion > ").strip()
        if user_input.lower() == 'fin':
            break
        try:
            parts = user_input.split(',')
            q, r, name = int(parts[0]), int(parts[1]), parts[2].strip()
            pieces.append(((q, r), {'name': name, 'team': team}))
        except Exception:
            print("Erreur de format. Utilisez 'q,r,Nom' (ex: 2,3,arc).")
    return pieces

def main():
    print("=====================================================")
    print("       VIZIR TACTIQUE - ASSISTANT POUR LEADERS       ")
    print("=====================================================")
    print("Général, l'échiquier hexagonal n'attend que vos ordres.")
    print("Le moteur Backtracking est activé pour forcer le destin.")
    
    while True:
        try:
            max_depth = int(input("\nProfondeur tactique max (Nombre total d'actions cumulées à anticiper, ex: 4) > "))
            break
        except ValueError:
            print("Veuillez entrer un nombre entier.")

    state = GameState()
    
    enemies = parse_input("POSITIONS ENNEMIES", "enemy")
    allies = parse_input("POSITIONS ALLIÉES", "ally")
    
    for pos, p in enemies + allies:
        state.board[pos] = p
        
    print("\n[Traitement en cours] Sondage des lignes temporelles... Calcul des trajectoires optimales...")
    
    score, sequence = find_winning_sequence(state, max_depth, maximizing_player=True)
    
    print("\n================= RAPPORT DE BATAILLE =================")
    if score >= 10:
        print("VICTOIRE TOTALE GARANTIE ! Suivez ces directives pour triompher de votre rival :\n")
        for i, move in enumerate(sequence):
            step_team = "Vos Forces" if i % 2 == 0 else "Riposte Ennemie Anticipée"
            print(f"[{step_team}] Étape {i+1} : {move['desc']}")
        print("\nLe lea ennemi tombera sous vos assauts !")
    elif score <= -10:
        print("ALERTE CRITIQUE : La configuration actuelle vous mène à une défaite certaine. Repliez-vous ou revoyez votre recrutement.")
    else:
        print(f"La victoire n'est pas garantie dans les {max_depth} prochains mouvements de pièces.")
        if sequence:
            print(f"La meilleure manœuvre d'ouverture suggérée est : {sequence[0]['desc']}")
            
    print("=======================================================")

if __name__ == "__main__":
    main()