import time
import random
from collections import defaultdict

# ==========================================
# ⚙️ PARAMÈTRES DU BOT INTERACTIF
# ==========================================

MAX_SEARCH_PLIES = 55             # Nombre max de déplacements de pions individuels à anticiper (remplace TARGET_TURNS)
MAX_THINK_TIME = 120              # Temps maximum de réflexion en secondes

MAX_BRANCHES = 12                 # Branches conservées après tri (réduit pour accélérer l'arbre par pion)
PRUNING_DEPTH_START = 2

FUTILITY_PRUNING_THRESHOLD = 50
MAX_QUIESCENCE_DEPTH = 2

HEURISTIC_WEIGHTS = {
    'dist_enemy_leader_base': 10, 
    'between_leaders': 5,         
    'enemy_near_leader_malus': {1: -20, 2: -10, 3: -5}, 
    'edge_malus': -5,             
    'spread_dist_2': 3,           
    'los_malus': -4               
}

TRAITS = {
    'cog': {'colle_ennemis': 5, 'colle_allies': 2, 'protege_leader': 3},
    'geo': {'colle_ennemis': 5, 'protege_leader': 5},
    'acr': {'colle_ennemis': 2, 'colle_allies': 2, 'pres_leader_ennemi': 2, 'bords': 1},
    'pro': {'colle_allies': 5, 'gene_vue': 3, 'protege_leader': 4},
    'tav': {'colle_allies': 4, 'centre': 5},
    'rod': {'pres_leader_ennemi': 2, 'gene_vue': 4, 'protege_leader': 3},
    'gar': {'pres_leader_ennemi': 2, 'protege_leader': 2},
    'ass': {'pres_leader_ennemi': 4},
    'nem': {'pres_leader_ennemi': 5, 'bords': 2},
    'arc': {'centre': 5},
    'ill': {'centre': 1, 'bords': 2, 'aime_voir_ennemis': 1, 'aime_voir_allies': 4},
    'man': {'bords': 2, 'aime_voir_ennemis': 5},
    'lan': {'bords': 4},
    'our': {'protege_leader': 5}
}

EXACT, LOWERBOUND, UPPERBOUND = 0, 1, 2

# ==========================================
# ⚡ PRÉCALCULS GLOBAUX
# ==========================================

ZOBRIST_KEYS = defaultdict(lambda: random.getrandbits(64))
DIRECTIONS = [(0, 1), (-1, 1), (1, 0), (1, -1), (0, -1), (-1, 0)]

VALID_HEXES = set()
VALID_HEXES.update([(1, r) for r in range(4, 8)])
VALID_HEXES.update([(2, r) for r in range(3, 8)])
VALID_HEXES.update([(3, r) for r in range(2, 8)])
VALID_HEXES.update([(4, r) for r in range(1, 8)])
VALID_HEXES.update([(5, r) for r in range(1, 7)])
VALID_HEXES.update([(6, r) for r in range(1, 6)])
VALID_HEXES.update([(7, r) for r in range(1, 5)])

PRECOMPUTED_NEIGHBORS = {}
EDGE_HEXES = set()
DIST = {}
VISIBLE_RAYS = {}

for q, r in VALID_HEXES:
    PRECOMPUTED_NEIGHBORS[(q, r)] = [(q+dq, r+dr) for dq, dr in DIRECTIONS if (q+dq, r+dr) in VALID_HEXES]
    if len(PRECOMPUTED_NEIGHBORS[(q, r)]) < 6: EDGE_HEXES.add((q, r))
    for q2, r2 in VALID_HEXES:
        DIST[((q, r), (q2, r2))] = (abs(q - q2) + abs(q + r - q2 - r2) + abs(r - r2)) // 2
    
    VISIBLE_RAYS[(q, r)] = []
    for dq, dr in DIRECTIONS:
        ray = []
        cq, cr = q + dq, r + dr
        while (cq, cr) in VALID_HEXES:
            ray.append((cq, cr))
            cq, cr = cq + dq, cr + dr
        if ray: VISIBLE_RAYS[(q, r)].append(ray)

def fmt(pos): 
    return f" {pos[0]}.{pos[1]}" # Ajout de l'espace demandé précédemment

# ==========================================
# MOTEUR DE RÈGLES
# ==========================================

class GameState:
    def __init__(self):
        self.board = {}
        self.team_counts = {'ally': 0, 'enemy': 0}
        self.current_team = 'ally'
        self.last_moved_team = None
        self.pieces_moved_this_turn = set()
        self.zobrist_hash = 0

    def init_hash(self):
        self.zobrist_hash = 0
        for pos, piece in self.board.items():
            self.zobrist_hash ^= ZOBRIST_KEYS[(pos[0], pos[1], piece['name'], piece['team'])]
        for pos in self.pieces_moved_this_turn:
            self.zobrist_hash ^= ZOBRIST_KEYS[('moved', pos[0], pos[1])]
        if self.current_team == 'enemy':
            self.zobrist_hash ^= ZOBRIST_KEYS['team_enemy']

    def get_visible_pieces(self, q, r):
        visible = []
        for ray in VISIBLE_RAYS[(q, r)]:
            d = 1
            for pos in ray:
                if pos in self.board:
                    visible.append({'pos': pos, 'piece': self.board[pos], 'dist': d})
                    break
                d += 1
        return visible

    def check_victory(self):
        defeated = set()
        for pos, piece in self.board.items():
            if piece['name'] == 'lea':
                team = piece['team']
                opp = 'enemy' if team == 'ally' else 'ally'
                neighbors = PRECOMPUTED_NEIGHBORS[pos]
                
                enemy_count = sum(1 for n in neighbors if n in self.board and self.board[n]['team'] == opp)
                
                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opp:
                        if self.board[n]['name'] == 'ass': enemy_count += 10
                        if self.board[n]['name'] in ['our', 'arc']: enemy_count -= 1
                        
                for ray in VISIBLE_RAYS[pos]:
                    if len(ray) >= 2:
                        tgt = ray[1]
                        if tgt in self.board and self.board[tgt]['team'] == opp and self.board[tgt]['name'] == 'arc':
                            enemy_count += 1

                if enemy_count >= 2 or (len(neighbors) > 0 and all(n in self.board for n in neighbors)):
                    defeated.add(team)

        if 'ally' in defeated and 'enemy' not in defeated: return 'enemy'
        if 'enemy' in defeated and 'ally' not in defeated: return 'ally'
        if 'ally' in defeated and 'enemy' in defeated:
            actor = self.last_moved_team if self.last_moved_team else self.current_team
            return 'enemy' if actor == 'ally' else 'ally'
        return None

    def make_move(self, move):
        undo = {'old_team': self.current_team, 'old_last_moved': self.last_moved_team, 
                'old_moved': set(self.pieces_moved_this_turn), 'board_restore': {}, 
                'old_hash': self.zobrist_hash, 'old_counts': self.team_counts.copy()}
        
        self.last_moved_team = self.current_team
        sqs = set([move['from'], move['to']])
        if 'push_target' in move: sqs.update([move['push_target'], move['push_to']])
        if 'target' in move: sqs.add(move['target'])
        
        for sq in sqs:
            p = self.board.get(sq)
            undo['board_restore'][sq] = p
            if p: 
                self.zobrist_hash ^= ZOBRIST_KEYS[(sq[0], sq[1], p['name'], p['team'])]
                self.team_counts[p['team']] -= 1
        
        if move['type'] == 'swap':
            self.board[move['to']], self.board[move['from']] = self.board.pop(move['from']), self.board.pop(move['to'])
        elif move['type'] != 'pass':
            pc = self.board.pop(move['from'])
            if 'push_target' in move:
                self.board[move['push_to']] = self.board.pop(move['push_target'])
            elif 'target' in move:
                self.board[move['to']] = self.board.pop(move['target'])
            self.board[move['to']] = pc
                
        for sq in sqs:
            p = self.board.get(sq)
            if p: 
                self.zobrist_hash ^= ZOBRIST_KEYS[(sq[0], sq[1], p['name'], p['team'])]
                self.team_counts[p['team']] += 1
                
        actor_end = move['from'] if ('target' in move and 'push_target' not in move) else move['to']
        
        if actor_end not in self.pieces_moved_this_turn:
            self.pieces_moved_this_turn.add(actor_end)
            self.zobrist_hash ^= ZOBRIST_KEYS[('moved', actor_end[0], actor_end[1])]

        if len(self.pieces_moved_this_turn) >= self.team_counts[self.current_team]:
            self.current_team = 'enemy' if self.current_team == 'ally' else 'ally'
            self.zobrist_hash ^= ZOBRIST_KEYS['team_enemy'] 
            for pos in self.pieces_moved_this_turn:
                self.zobrist_hash ^= ZOBRIST_KEYS[('moved', pos[0], pos[1])]
            self.pieces_moved_this_turn.clear()

        return undo

    def unmake_move(self, undo):
        self.current_team = undo['old_team']
        self.last_moved_team = undo['old_last_moved']
        self.pieces_moved_this_turn = undo['old_moved']
        self.team_counts = undo['old_counts']
        
        for sq, p in undo['board_restore'].items():
            if p is None: self.board.pop(sq, None)
            else: self.board[sq] = p
        self.zobrist_hash = undo['old_hash']

def generate_moves_for_piece(state, q, r, piece):
    moves = []
    f_str = fmt((q, r))
    moves.append({'type': 'pass', 'team': piece['team'], 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']}{f_str} passe"})

    empty_n = [n for n in PRECOMPUTED_NEIGHBORS[(q, r)] if n not in state.board]
    name = piece['name']
    
    for n in empty_n: moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': n, 'desc': f"{name}{f_str} >{fmt(n)}"})

    if any(n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'geo' for n in PRECOMPUTED_NEIGHBORS[(q, r)]):
        return moves

    if name == 'cav':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q+dq, r+dr), (q+2*dq, r+2*dr)
            if n1 in VALID_HEXES and n2 in VALID_HEXES and n1 not in state.board and n2 not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n2, 'desc': f"cav{f_str} >{fmt(n2)}"})
    elif name == 'nem': 
        for h in VALID_HEXES:
            if h not in state.board and DIST[((q, r), h)] == 2:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': h, 'desc': f"nem{f_str} >{fmt(h)}"})
    elif name == 'cog':
        for n in PRECOMPUTED_NEIGHBORS[(q, r)]:
            if n in state.board and state.board[n]['team'] != piece['team']:
                for opp in [x for x in PRECOMPUTED_NEIGHBORS[n] if x != (q, r) and x not in PRECOMPUTED_NEIGHBORS[(q, r)]]:
                    if opp not in state.board and opp in VALID_HEXES:
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n, 'push_target': n, 'push_to': opp, 'desc': f"cog{f_str} >{fmt(n)} (pousse{fmt(opp)})"})
    elif name == 'acr':
        for n in PRECOMPUTED_NEIGHBORS[(q, r)]:
            if n in state.board:
                jump = (n[0] + (n[0]-q), n[1] + (n[1]-r))
                if jump not in state.board and jump in VALID_HEXES:
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': jump, 'desc': f"acr{f_str} >{fmt(jump)}"})
    
    return moves

# ==========================================
# MOTEUR DE RECHERCHE & HEURISTIQUES
# ==========================================

class SearchEngine:
    def __init__(self):
        self.tt = {}
        self.nodes = 0
        self.killer_moves = defaultdict(lambda: [None, None])
        self.history_table = defaultdict(int)
        self.start_time = 0
        self.time_out = False

    def reset_data(self):
        self.tt.clear()
        self.killer_moves.clear()
        self.history_table.clear()
        self.nodes = 0
        self.time_out = False

    def evaluate(self, state):
        score = 0
        leaders = {p['team']: pos for pos, p in state.board.items() if p['name'] == 'lea'}
        ally_lea, enemy_lea = leaders.get('ally'), leaders.get('enemy')

        for pos, p in state.board.items():
            val = 0
            team, opp = p['team'], 'enemy' if p['team'] == 'ally' else 'ally'
            my_lea, his_lea = (ally_lea, enemy_lea) if team == 'ally' else (enemy_lea, ally_lea)
            traits = TRAITS.get(p['name'], {})

            if his_lea: val += (10 - DIST[(pos, his_lea)]) * HEURISTIC_WEIGHTS['dist_enemy_leader_base']
            if my_lea and his_lea and DIST[(pos, my_lea)] + DIST[(pos, his_lea)] == DIST[(my_lea, his_lea)]:
                val += HEURISTIC_WEIGHTS['between_leaders']
                if 'protege_leader' in traits: val += traits['protege_leader'] * 10
            if my_lea and team == opp and DIST[(pos, my_lea)] in HEURISTIC_WEIGHTS['enemy_near_leader_malus']:
                val += HEURISTIC_WEIGHTS['enemy_near_leader_malus'][DIST[(pos, my_lea)]]
            if pos in EDGE_HEXES:
                val += HEURISTIC_WEIGHTS['edge_malus']
                if 'bords' in traits: val += traits['bords'] * 5
            if my_lea and DIST[(pos, my_lea)] == 2: val += HEURISTIC_WEIGHTS['spread_dist_2']

            n_allies = sum(1 for n in PRECOMPUTED_NEIGHBORS[pos] if n in state.board and state.board[n]['team']==team)
            n_enemies = sum(1 for n in PRECOMPUTED_NEIGHBORS[pos] if n in state.board and state.board[n]['team']==opp)
            
            if 'colle_ennemis' in traits: val += n_enemies * traits['colle_ennemis'] * 5
            if 'colle_allies' in traits: val += n_allies * traits['colle_allies'] * 5
            if 'pres_leader_ennemi' in traits and his_lea: val += (10 - DIST[(pos, his_lea)]) * traits['pres_leader_ennemi'] * 3
            if 'centre' in traits: val += (10 - DIST[(pos, (4, 4))]) * traits['centre'] * 2
            
            if 'aime_voir_ennemis' in traits or 'aime_voir_allies' in traits:
                vis = state.get_visible_pieces(pos[0], pos[1])
                if 'aime_voir_ennemis' in traits: val += sum(1 for v in vis if v['piece']['team'] == opp) * traits['aime_voir_ennemis'] * 4
                if 'aime_voir_allies' in traits: val += sum(1 for v in vis if v['piece']['team'] == team) * traits['aime_voir_allies'] * 4

            score += val if team == 'ally' else -val
        return score

    def quiescence_search(self, state, alpha, beta, is_max, qs_depth):
        self.nodes += 1
        stand_pat = self.evaluate(state)

        if is_max:
            if stand_pat >= beta: return beta
            alpha = max(alpha, stand_pat)
        else:
            if stand_pat <= alpha: return alpha
            beta = min(beta, stand_pat)

        if qs_depth == 0 or self.time_out: return stand_pat

        team = 'ally' if is_max else 'enemy'
        noisy_moves = []
        for pos, p in state.board.items():
            if p['team'] == team and pos not in state.pieces_moved_this_turn:
                moves = generate_moves_for_piece(state, pos[0], pos[1], p)
                noisy_moves.extend([m for m in moves if m['type'] == 'skill'])

        for m in noisy_moves:
            undo = state.make_move(m)
            nxt_max = (state.current_team == 'ally')
            score = self.quiescence_search(state, alpha, beta, nxt_max, qs_depth - 1)
            state.unmake_move(undo)
            if is_max:
                if score >= beta: return beta
                alpha = max(alpha, score)
            else:
                if score <= alpha: return alpha
                beta = min(beta, score)
        return alpha if is_max else beta

    def alphabeta(self, state, depth, alpha, beta, is_max, current_max_depth):
        if time.time() - self.start_time > MAX_THINK_TIME:
            self.time_out = True
            return 0, None

        self.nodes += 1
        h, alpha_orig, beta_orig = state.zobrist_hash, alpha, beta
        tt_best_move, static_eval = None, None

        if h in self.tt:
            tt_depth, tt_val, tt_flag, tt_tree, tt_eval = self.tt[h]
            static_eval = tt_eval 
            if tt_depth >= depth:
                if tt_flag == EXACT: return tt_val, tt_tree
                elif tt_flag == LOWERBOUND: alpha = max(alpha, tt_val)
                elif tt_flag == UPPERBOUND: beta = min(beta, tt_val)
                if alpha >= beta: return tt_val, tt_tree
            if tt_tree and 'move' in tt_tree: tt_best_move = tt_tree['move']

        winner = state.check_victory()
        if winner == 'ally': return 1000 + depth, None
        if winner == 'enemy': return -1000 - depth, None
        if static_eval is None: static_eval = self.evaluate(state)

        if depth < current_max_depth:
            if is_max and static_eval >= FUTILITY_PRUNING_THRESHOLD: return static_eval, None
            if not is_max and static_eval <= -FUTILITY_PRUNING_THRESHOLD: return static_eval, None

        if depth == 0: 
            qs_eval = self.quiescence_search(state, alpha, beta, is_max, MAX_QUIESCENCE_DEPTH)
            self.tt[h] = (depth, qs_eval, EXACT, None, static_eval)
            return qs_eval, None

        team = 'ally' if is_max else 'enemy'
        moves = []
        for pos, p in state.board.items():
            if p['team'] == team and pos not in state.pieces_moved_this_turn:
                if p['name'] == 'arc' and pos == (4, 4):
                    moves.append({'type': 'pass', 'team': team, 'from': pos, 'to': pos, 'desc': f"{p['name']}{fmt(pos)} passe"})
                else:
                    moves.extend(generate_moves_for_piece(state, pos[0], pos[1], p))
                
        def score_move(m):
            score = 0
            if tt_best_move and m == tt_best_move: return 1000000 
            if self.killer_moves[depth][0] == m: return 900000
            if self.killer_moves[depth][1] == m: return 800000
            score += self.history_table[f"{m['from']}_{m['to']}_{m.get('type')}"]
            if m['type'] == 'skill': score += 500 
            elif m['type'] == 'move': score += 100 
            elif m['type'] == 'pass': score -= 1000
            return score

        moves.sort(key=score_move, reverse=True)
        current_branch_limit = MAX_BRANCHES if depth > PRUNING_DEPTH_START else len(moves)
        moves = moves[:current_branch_limit] + [m for m in moves[current_branch_limit:] if m['type'] == 'skill']

        best_tree = None
        opt_val = -float('inf') if is_max else float('inf')

        for m in moves:
            undo = state.make_move(m)
            
            # 🔥 LE CORRECTIF EST ICI : La profondeur descend d'un cran à CHAQUE pion bougé
            next_depth = depth - 1 
            
            eval_score, sub = self.alphabeta(state, next_depth, alpha, beta, state.current_team == 'ally', current_max_depth)
            state.unmake_move(undo)
            if self.time_out: return 0, None

            if is_max:
                if eval_score > opt_val:
                    opt_val, best_tree = eval_score, {'move': m, 'next': sub}
                alpha = max(alpha, eval_score)
                if beta <= alpha:
                    if m['type'] != 'skill':
                        self.killer_moves[depth][1] = self.killer_moves[depth][0]
                        self.killer_moves[depth][0] = m
                        self.history_table[f"{m['from']}_{m['to']}_{m.get('type')}"] += depth ** 2
                    break
            else:
                if eval_score < opt_val:
                    opt_val, best_tree = eval_score, {'move': m, 'next': sub}
                beta = min(beta, eval_score)
                if beta <= alpha:
                    if m['type'] != 'skill':
                        self.killer_moves[depth][1] = self.killer_moves[depth][0]
                        self.killer_moves[depth][0] = m
                        self.history_table[f"{m['from']}_{m['to']}_{m.get('type')}"] += depth ** 2
                    break

        tt_flag = EXACT if (alpha_orig < opt_val < beta_orig) else (UPPERBOUND if opt_val <= alpha_orig else LOWERBOUND)
        self.tt[h] = (depth, opt_val, tt_flag, best_tree, static_eval)
        return opt_val, best_tree

    def find_best_move_iterative(self, state, target_depth):
        self.start_time = time.time()
        self.time_out = False
        best_tree, best_score = None, 0
        
        for d in range(1, target_depth + 1):
            t_start_depth = time.time() 
            
            score, tree = self.alphabeta(state, d, -float('inf'), float('inf'), state.current_team == 'ally', d)
            
            if self.time_out:
                print(f"⏱️ Temps écoulé ({MAX_THINK_TIME}s). Arrêt à la profondeur de recherche {d-1}.")
                break
                
            elapsed_depth = time.time() - t_start_depth 
            #print(f"-> Profondeur {d} explorée en {elapsed_depth:.4f} secondes (Score éval: {score})")
            
            best_score, best_tree, depth = score, tree, d
            
        return best_score, best_tree, depth

# ==========================================
# GESTION INTERACTIVE (BOT)
# ==========================================

def extract_pv(tree):
    """Extrait la ligne principale en séparant visuellement les tours."""
    pv_lines = []
    curr = tree
    current_team = None
    current_line = []
    
    while curr and 'move' in curr:
        m = curr['move']
        # Si on change d'équipe, on finalise la ligne en cours et on en crée une nouvelle
        if m['team'] != current_team:
            if current_line:
                pv_lines.append(" ➔ ".join(current_line))
            current_team = m['team']
            icon = "🟦" if current_team == 'ally' else "🟥"
            current_line = [f"\n{icon} [TOUR {current_team.upper()}] : {m['desc']}"]
        else:
            current_line.append(m['desc'])
            
        curr = curr.get('next')
        
    # On ajoute la toute dernière ligne
    if current_line:
        pv_lines.append(" ➔ ".join(current_line))
        
    return "".join(pv_lines)

def parse_initial_input(prompt_text, team):
    print(f"\n--- {prompt_text} ---")
    pieces = []
    while True:
        ui = input(f"[{team.upper()}] (ex: 1.1.arc / 'fin') > ").strip()
        if ui.lower() == 'fin': break
        try:
            p = ui.split('.')
            pieces.append(((int(p[0]), int(p[1])), {'name': p[2], 'team': team}))
        except: print("❌ Format invalide.")
    return pieces

def get_all_legal_moves(state):
    moves = []
    for pos, p in state.board.items():
        if p['team'] == state.current_team and pos not in state.pieces_moved_this_turn:
            moves.extend(generate_moves_for_piece(state, pos[0], pos[1], p))
    return moves

def play_match():
    print("=== 🤖 BOT TEMPS RÉEL V10 (Optimisé Multi-Actions) ===")
    enemies = parse_initial_input("ENNEMIS", "enemy")
    allies = parse_initial_input("ALLIÉS", "ally")
    
    state = GameState()
    for pos, p in enemies + allies: 
        state.board[pos] = p
        state.team_counts[p['team']] += 1
    state.init_hash()
    
    engine = SearchEngine()
    
    while True:
        winner = state.check_victory()
        if winner:
            print(f"\n🏆 PARTIE TERMINÉE ! Vainqueur : {winner.upper()}")
            break

        print(f"\n\n=========================================")
        print(f"🔄 TOUR DE L'ÉQUIPE : {state.current_team.upper()}")
        print(f"🧠 Recherche... {MAX_THINK_TIME}s max...")
        
        score, tree, depth = engine.find_best_move_iterative(state, MAX_SEARCH_PLIES)
        
        if not tree or 'move' not in tree:
            print("⚠️ Aucun mouvement trouvé (Fin de partie imminente ou erreur).")
            break
            
        recommended_move = tree['move']
        print(f"a anticipé {depth} coups")
        print(f"\n🎯 SCORE ÉVALUÉ : {score}")
        print(f"💡 COUP RECOMMANDÉ : {recommended_move['desc']}")
        print(f"🔮 PRÉVISION (PV) : {extract_pv(tree)}")
        
        legal_moves = get_all_legal_moves(state)
        played_move = None
        
        while not played_move:
            print("\nEntrez le coup réellement joué pour mettre à jour le plateau.")
            print("- Tapez 'y' pour jouer le coup recommandé ci-dessus.")
            print("- Ou entrez un déplacement manuel (ex: 1.1-2.2)")
            print("- Tapez 'exit' pour quitter.")
            ui = input("> ").strip().lower()
            
            if ui == 'exit': return
            if ui == 'y':
                played_move = recommended_move
                break
                
            try:
                fr, to = ui.split('-')
                start = (int(fr.split('.')[0]), int(fr.split('.')[1]))
                end = (int(to.split('.')[0]), int(to.split('.')[1]))
                
                for m in legal_moves:
                    if m['from'] == start and m['to'] == end:
                        played_move = m
                        break
                
                if not played_move:
                    print("❌ Mouvement illégal ou introuvable. Réessayez.")
            except:
                print("❌ Format invalide. Utilisez X.Y-A.B (ex: 1.1-2.2)")
        
        if state.current_team == 'enemy' and played_move != recommended_move:
            print("\n⚠️ ATTENTION : L'adversaire n'a pas joué le coup prévu ! Configuration non prévue.")
            print("🔄 Recalcul total des nouvelles probabilités au prochain tour...")
        
        state.make_move(played_move)
        engine.reset_data() 
        print(f"✅ Plateau mis à jour. Coup joué : {played_move['desc']}")

if __name__ == "__main__":
    play_match()