import time
import random
from collections import defaultdict

# ==========================================
# ⚙️ PARAMÈTRES RÉGLABLES PAR L'UTILISATEUR
# ==========================================

MAX_BRANCHES = 2                 # (Min: 1, Max: ~100) Nombre de coups standards conservés.
PRUNING_DEPTH_START = 0           # (Min: 0, Max: Profondeur max) On élague uniquement si la profondeur restante <= à ce chiffre.
HEURISTIC_IGNORE_THRESHOLD = 260  # (Min: 0, Max: 1000) Si notre score dépasse ce seuil, on explore tout.

HEURISTIC_WEIGHTS = {
    'dist_enemy_leader_base': 10, 
    'between_leaders': 5,         
    'enemy_near_leader_malus': {1: -20, 2: -10, 3: -5}, 
    'edge_malus': -5,             
    'spread_dist_2': 3,           
    'los_malus': -4               
}

TRAITS = {
    'cog': {'colle_ennemis': 5, 'colle_allies': 2, 'protege_leader': 3},
    'geo': {'colle_ennemis': 5, 'protege_leader': 5},
    'acr': {'colle_ennemis': 2, 'colle_allies': 2, 'pres_leader_ennemi': 2, 'bords': 1},
    'pro': {'colle_allies': 5, 'gene_vue': 3, 'protege_leader': 4},
    'tav': {'colle_allies': 4, 'centre': 5},
    'rod': {'pres_leader_ennemi': 2, 'gene_vue': 4, 'protege_leader': 3},
    'gar': {'pres_leader_ennemi': 2, 'protege_leader': 2},
    'ass': {'pres_leader_ennemi': 4},
    'nem': {'pres_leader_ennemi': 5, 'bords': 2},
    'arc': {'centre': 5},
    'ill': {'centre': 1, 'bords': 2, 'aime_voir_ennemis': 1, 'aime_voir_allies': 4},
    'man': {'bords': 2, 'aime_voir_ennemis': 5},
    'lan': {'bords': 4},
    'our': {'protege_leader': 5}
}

# Constantes pour la Table de Transposition (Alpha-Beta)
EXACT = 0
LOWERBOUND = 1
UPPERBOUND = 2

# ==========================================
# ⚡ PRÉCALCULS GLOBAUX (CACHE)
# ==========================================

ZOBRIST_KEYS = defaultdict(lambda: random.getrandbits(64))
DIRECTIONS = [(0, 1), (-1, 1), (1, 0), (1, -1), (0, -1), (-1, 0)]

VALID_HEXES = set()
VALID_HEXES.update([(1, r) for r in range(4, 8)])
VALID_HEXES.update([(2, r) for r in range(3, 8)])
VALID_HEXES.update([(3, r) for r in range(2, 8)])
VALID_HEXES.update([(4, r) for r in range(1, 8)])
VALID_HEXES.update([(5, r) for r in range(1, 7)])
VALID_HEXES.update([(6, r) for r in range(1, 6)])
VALID_HEXES.update([(7, r) for r in range(1, 5)])

PRECOMPUTED_NEIGHBORS = {}
EDGE_HEXES = set()
DIST = {}
VISIBLE_RAYS = {}

for q, r in VALID_HEXES:
    PRECOMPUTED_NEIGHBORS[(q, r)] = [(q+dq, r+dr) for dq, dr in DIRECTIONS if (q+dq, r+dr) in VALID_HEXES]
    if len(PRECOMPUTED_NEIGHBORS[(q, r)]) < 6:
        EDGE_HEXES.add((q, r))
    for q2, r2 in VALID_HEXES:
        DIST[((q, r), (q2, r2))] = (abs(q - q2) + abs(q + r - q2 - r2) + abs(r - r2)) // 2
    
    VISIBLE_RAYS[(q, r)] = []
    for dq, dr in DIRECTIONS:
        ray = []
        cq, cr = q + dq, r + dr
        while (cq, cr) in VALID_HEXES:
            ray.append((cq, cr))
            cq, cr = cq + dq, cr + dr
        if ray:
            VISIBLE_RAYS[(q, r)].append(ray)

def fmt(pos): return f"{pos[0]}.{pos[1]}"

# ==========================================
# INITIALISATION & MOTEUR DE RÈGLES
# ==========================================

class GameState:
    def __init__(self):
        self.board = {}
        self.team_counts = {'ally': 0, 'enemy': 0}
        self.current_team = 'ally'
        self.last_moved_team = None
        self.pieces_moved_this_turn = set()
        self.zobrist_hash = 0

    def init_hash(self):
        self.zobrist_hash = 0
        for pos, piece in self.board.items():
            self.zobrist_hash ^= ZOBRIST_KEYS[(pos[0], pos[1], piece['name'], piece['team'])]
        for pos in self.pieces_moved_this_turn:
            self.zobrist_hash ^= ZOBRIST_KEYS[('moved', pos[0], pos[1])]
        if self.current_team == 'enemy':
            self.zobrist_hash ^= ZOBRIST_KEYS['team_enemy']

    def get_visible_pieces(self, q, r):
        visible = []
        for ray in VISIBLE_RAYS[(q, r)]:
            d = 1
            for pos in ray:
                if pos in self.board:
                    visible.append({'pos': pos, 'piece': self.board[pos], 'dist': d})
                    break
                d += 1
        return visible

    def check_victory(self):
        defeated = set()
        for pos, piece in self.board.items():
            if piece['name'] == 'lea':
                team = piece['team']
                opp = 'enemy' if team == 'ally' else 'ally'
                neighbors = PRECOMPUTED_NEIGHBORS[pos]
                
                enemy_count = sum(1 for n in neighbors if n in self.board and self.board[n]['team'] == opp)
                
                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opp:
                        if self.board[n]['name'] == 'ass': enemy_count += 10
                        if self.board[n]['name'] in ['our', 'arc']: enemy_count -= 1
                        
                for ray in VISIBLE_RAYS[pos]:
                    if len(ray) >= 2:
                        tgt = ray[1]
                        if tgt in self.board and self.board[tgt]['team'] == opp and self.board[tgt]['name'] == 'arc':
                            enemy_count += 1

                if enemy_count >= 2 or (len(neighbors) > 0 and all(n in self.board for n in neighbors)):
                    defeated.add(team)

        if 'ally' in defeated and 'enemy' not in defeated: return 'enemy'
        if 'enemy' in defeated and 'ally' not in defeated: return 'ally'
        if 'ally' in defeated and 'enemy' in defeated:
            actor = self.last_moved_team if self.last_moved_team else self.current_team
            return 'enemy' if actor == 'ally' else 'ally'
        return None

    def make_move(self, move):
        undo = {'old_team': self.current_team, 'old_last_moved': self.last_moved_team, 
                'old_moved': set(self.pieces_moved_this_turn), 'board_restore': {}, 
                'old_hash': self.zobrist_hash, 'old_counts': self.team_counts.copy()}
        
        self.last_moved_team = self.current_team
        sqs = set([move['from'], move['to']])
        if 'push_target' in move: sqs.update([move['push_target'], move['push_to']])
        if 'target' in move: sqs.add(move['target'])
        
        # O(1) : Mise à jour Zobrist & Effectifs AVANT modification
        for sq in sqs:
            p = self.board.get(sq)
            undo['board_restore'][sq] = p
            if p: 
                self.zobrist_hash ^= ZOBRIST_KEYS[(sq[0], sq[1], p['name'], p['team'])]
                self.team_counts[p['team']] -= 1
        
        # Mouvements logiques
        if move['type'] == 'swap':
            self.board[move['to']], self.board[move['from']] = self.board.pop(move['from']), self.board.pop(move['to'])
        elif move['type'] != 'pass':
            pc = self.board.pop(move['from'])
            if 'push_target' in move:
                self.board[move['push_to']] = self.board.pop(move['push_target'])
            elif 'target' in move:
                self.board[move['to']] = self.board.pop(move['target'])
            self.board[move['to']] = pc
                
        # O(1) : Mise à jour Zobrist & Effectifs APRÈS modification
        for sq in sqs:
            p = self.board.get(sq)
            if p: 
                self.zobrist_hash ^= ZOBRIST_KEYS[(sq[0], sq[1], p['name'], p['team'])]
                self.team_counts[p['team']] += 1
                
        actor_end = move['from'] if ('target' in move and 'push_target' not in move) else move['to']
        
        if actor_end not in self.pieces_moved_this_turn:
            self.pieces_moved_this_turn.add(actor_end)
            self.zobrist_hash ^= ZOBRIST_KEYS[('moved', actor_end[0], actor_end[1])]

        # Utilisation du cache O(1) pour la condition de fin de tour
        if len(self.pieces_moved_this_turn) >= self.team_counts[self.current_team]:
            self.current_team = 'enemy' if self.current_team == 'ally' else 'ally'
            self.zobrist_hash ^= ZOBRIST_KEYS['team_enemy'] 
            
            for pos in self.pieces_moved_this_turn:
                self.zobrist_hash ^= ZOBRIST_KEYS[('moved', pos[0], pos[1])]
            self.pieces_moved_this_turn.clear()

        return undo

    def unmake_move(self, undo):
        self.current_team = undo['old_team']
        self.last_moved_team = undo['old_last_moved']
        self.pieces_moved_this_turn = undo['old_moved']
        self.team_counts = undo['old_counts']
        
        for sq, p in undo['board_restore'].items():
            if p is None: self.board.pop(sq, None)
            else: self.board[sq] = p
            
        self.zobrist_hash = undo['old_hash']

# ==========================================
# GÉNÉRATION DES COUPS 
# ==========================================

def generate_moves_for_piece(state, q, r, piece):
    moves = []
    f_str = fmt((q, r))
    moves.append({'type': 'pass', 'team': piece['team'], 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']}{f_str} passe"})

    empty_n = [n for n in PRECOMPUTED_NEIGHBORS[(q, r)] if n not in state.board]
    name = piece['name']
    
    for n in empty_n:
        moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': n, 'desc': f"{name}{f_str}>{fmt(n)}"})

    if any(n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'geo' for n in PRECOMPUTED_NEIGHBORS[(q, r)]):
        return moves

    if name == 'cav':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q+dq, r+dr), (q+2*dq, r+2*dr)
            if n1 in VALID_HEXES and n2 in VALID_HEXES and n1 not in state.board and n2 not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n2, 'desc': f"cav{f_str}>{fmt(n2)}"})
    elif name == 'nem': 
        for h in VALID_HEXES:
            if h not in state.board and DIST[((q, r), h)] == 2:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': h, 'desc': f"nem{f_str}>{fmt(h)}"})
    elif name == 'cog':
        for n in PRECOMPUTED_NEIGHBORS[(q, r)]:
            if n in state.board and state.board[n]['team'] != piece['team']:
                for opp in [x for x in PRECOMPUTED_NEIGHBORS[n] if x != (q, r) and x not in PRECOMPUTED_NEIGHBORS[(q, r)]]:
                    if opp not in state.board and opp in VALID_HEXES:
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n, 'push_target': n, 'push_to': opp, 'desc': f"cog{f_str}>{fmt(n)}(pousse {fmt(opp)})"})
    elif name == 'acr':
        for n in PRECOMPUTED_NEIGHBORS[(q, r)]:
            if n in state.board:
                jump = (n[0] + (n[0]-q), n[1] + (n[1]-r))
                if jump not in state.board and jump in VALID_HEXES:
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': jump, 'desc': f"acr{f_str}>{fmt(jump)}"})
    
    return moves

# ==========================================
# HEURISTIQUE ET MOTEUR
# ==========================================

class SearchEngine:
    def __init__(self):
        self.tt = {}
        self.nodes = 0
        self.tt_hits = 0

    def evaluate(self, state):
        score = 0
        leaders = {p['team']: pos for pos, p in state.board.items() if p['name'] == 'lea'}
        ally_lea = leaders.get('ally')
        enemy_lea = leaders.get('enemy')

        for pos, p in state.board.items():
            val = 0
            team = p['team']
            opp = 'enemy' if team == 'ally' else 'ally'
            my_lea = ally_lea if team == 'ally' else enemy_lea
            his_lea = enemy_lea if team == 'ally' else ally_lea
            name = p['name']
            traits = TRAITS.get(name, {})

            if his_lea:
                d_his = DIST[(pos, his_lea)]
                val += (10 - d_his) * HEURISTIC_WEIGHTS['dist_enemy_leader_base']
                
            if my_lea and his_lea:
                if DIST[(pos, my_lea)] + DIST[(pos, his_lea)] == DIST[(my_lea, his_lea)]:
                    val += HEURISTIC_WEIGHTS['between_leaders']
                    if 'protege_leader' in traits: val += traits['protege_leader'] * 10
                    
            if my_lea and team == opp:
                d_my_lea = DIST[(pos, my_lea)]
                if d_my_lea in HEURISTIC_WEIGHTS['enemy_near_leader_malus']:
                    val += HEURISTIC_WEIGHTS['enemy_near_leader_malus'][d_my_lea]

            if pos in EDGE_HEXES:
                val += HEURISTIC_WEIGHTS['edge_malus']
                if 'bords' in traits: val += traits['bords'] * 5
                
            if my_lea and DIST[(pos, my_lea)] == 2:
                val += HEURISTIC_WEIGHTS['spread_dist_2']

            n_allies = sum(1 for n in PRECOMPUTED_NEIGHBORS[pos] if n in state.board and state.board[n]['team']==team)
            n_enemies = sum(1 for n in PRECOMPUTED_NEIGHBORS[pos] if n in state.board and state.board[n]['team']==opp)
            
            if 'colle_ennemis' in traits: val += n_enemies * traits['colle_ennemis'] * 5
            if 'colle_allies' in traits: val += n_allies * traits['colle_allies'] * 5
            if 'pres_leader_ennemi' in traits and his_lea: val += (10 - DIST[(pos, his_lea)]) * traits['pres_leader_ennemi'] * 3
            if 'centre' in traits: val += (10 - DIST[(pos, (4, 4))]) * traits['centre'] * 2
            
            # Évaluation coûteuse de la vue optimisée
            if 'aime_voir_ennemis' in traits or 'aime_voir_allies' in traits:
                vis = state.get_visible_pieces(pos[0], pos[1])
                vis_opp = sum(1 for v in vis if v['piece']['team'] == opp)
                vis_ally = sum(1 for v in vis if v['piece']['team'] == team)
                
                if 'aime_voir_ennemis' in traits: val += vis_opp * traits['aime_voir_ennemis'] * 4
                if 'aime_voir_allies' in traits: val += vis_ally * traits['aime_voir_allies'] * 4

            score += val if team == 'ally' else -val

        return score

    def find_winning_sequence(self, state, depth, alpha, beta, is_max, current_max_depth=None):
        if current_max_depth is None:
            current_max_depth = depth

        self.nodes += 1
        h = state.zobrist_hash
        alpha_orig = alpha
        beta_orig = beta
        
        tt_best_move = None
        static_eval = None # Pour stocker l'évaluation statique issue du cache

        if h in self.tt:
            tt_depth, tt_val, tt_flag, tt_tree, tt_eval = self.tt[h] # Ajout de tt_eval dans le tuple
            static_eval = tt_eval 
            
            if tt_depth >= depth:
                self.tt_hits += 1
                if tt_flag == EXACT: return tt_val, tt_tree
                elif tt_flag == LOWERBOUND: alpha = max(alpha, tt_val)
                elif tt_flag == UPPERBOUND: beta = min(beta, tt_val)
                
                if alpha >= beta: return tt_val, tt_tree
                
            if tt_tree and 'move' in tt_tree:
                tt_best_move = tt_tree['move']

        winner = state.check_victory()
        if winner == 'ally': return 1000 + depth, None
        if winner == 'enemy': return -1000 - depth, None
        
        # Calcul de l'évaluation statique si elle n'est pas dans le cache
        if static_eval is None:
            static_eval = self.evaluate(state)

        if depth == 0: 
            # On stocke dans la TT même à la profondeur 0
            self.tt[h] = (depth, static_eval, EXACT, None, static_eval)
            return static_eval, None

        team = 'ally' if is_max else 'enemy'
        moves = []
        for pos, p in state.board.items():
            if p['team'] == team and pos not in state.pieces_moved_this_turn:
                moves.extend(generate_moves_for_piece(state, pos[0], pos[1], p))
                
        def score_move(m):
            if tt_best_move and m == tt_best_move: return 10000 
            score = 0
            if m['type'] == 'skill': score += 50 
            elif m['type'] == 'move': score += 10 
            elif m['type'] == 'pass': score -= 100
            if 'to' in m: score -= DIST.get((m['to'], (4, 4)), 0)
            return score

        moves.sort(key=score_move, reverse=True)
        
        # --- APPLICATION DES 3 NOUVEAUX PARAMÈTRES ---
        # 1. Par défaut, on garde la limite fixée
        current_branch_limit = MAX_BRANCHES
        
        # 2. Ignorer l'élagage si le score statique de l'allié est très haut
        # (Si on est l'ennemi, un score allié très bas signifie un gros avantage pour l'ennemi, on annule l'élagage aussi)
        if is_max and static_eval > HEURISTIC_IGNORE_THRESHOLD:
            current_branch_limit = len(moves)
        elif not is_max and static_eval < -HEURISTIC_IGNORE_THRESHOLD:
            current_branch_limit = len(moves)
            
        # 3. Profondeur d'élagage : On n'élague que si on s'enfonce assez profondément
        # Si la profondeur restante (depth) est supérieure à notre paramètre, on ne filtre pas.
        if depth > PRUNING_DEPTH_START:
            current_branch_limit = len(moves)

        # Soft-Pruning avec la limite dynamique
        top_moves = moves[:current_branch_limit]
        extra_moves = [m for m in moves[current_branch_limit:] if m['type'] == 'skill']
        moves = top_moves + extra_moves
        # ---------------------------------------------

        best_tree = {'team': team, 'responses': []} if not is_max else None
        opt_val = -float('inf') if is_max else float('inf')

        for m in moves:
            undo = state.make_move(m)
            
            team_changed = (state.current_team != undo['old_team'])
            next_depth = depth - 1 if team_changed else depth
            nxt_max = (state.current_team == 'ally')
            
            # On propage current_max_depth
            eval_score, sub = self.find_winning_sequence(state, next_depth, alpha, beta, nxt_max, current_max_depth)
            state.unmake_move(undo)

            if is_max:
                if eval_score > opt_val:
                    opt_val, best_tree = eval_score, {'team': 'ally', 'move': m, 'next': sub}
                alpha = max(alpha, eval_score)
                if beta <= alpha: break
            else:
                best_tree['responses'].append({'move': m, 'eval': eval_score, 'next': sub})
                opt_val = min(opt_val, eval_score)
                beta = min(beta, eval_score)
                if beta <= alpha: break

        # Enregistrement avec le nouveau format de la Table de Transposition (5 éléments)
        tt_flag = EXACT
        if opt_val <= alpha_orig:
            tt_flag = UPPERBOUND
        elif opt_val >= beta_orig:
            tt_flag = LOWERBOUND
            
        self.tt[h] = (depth, opt_val, tt_flag, best_tree, static_eval)
        return opt_val, best_tree

# ==========================================
# FORMATAGE MARKDOWN 
# ==========================================

def generate_markdown_from_tree(tree, visited=None):
    if not tree: return ""
    if visited is None: visited = set()
    
    t_id = id(tree)
    if t_id in visited: return "> 🔄 *[Boucle]*\n"
    visited.add(t_id)
    
    res = ""
    if tree.get('team') == 'ally':
        curr = tree
        while curr and curr.get('team') == 'ally':
            if id(curr) in visited and curr != tree: break
            visited.add(id(curr))
            if 'move' in curr: res += f"- **{curr['move']['desc']}**\n"
            curr = curr.get('next')
        if curr: res += generate_markdown_from_tree(curr, visited.copy())
        else: res += "> ✅ **[Victoire]**\n"
        
    elif tree.get('team') == 'enemy':
        res += "\n"
        for r in sorted(tree.get('responses', []), key=lambda x: x.get('eval', 0)):
            res += f"<details><summary>{r['move']['desc']} [{r.get('eval',0)}]</summary>\n\n"
            if r.get('next'): res += generate_markdown_from_tree(r.get('next'), visited.copy())
            res += "</details>\n"
    return res

# ==========================================
# CLI
# ==========================================

def parse_input(prompt_text, team):
    print(f"\n--- {prompt_text} ---")
    pieces = []
    while True:
        ui = input(f"[{team.upper()}] (ex: 1.1.arc / 'fin') > ").strip()
        if ui.lower() == 'fin': break
        try:
            p = ui.split('.')
            pieces.append(((int(p[0]), int(p[1])), {'name': p[2], 'team': team}))
        except: print("Format invalide.")
    return pieces

def main():
    print("=== MOTEUR V7 - FULL OPTI & STABILITÉ TT ===")
    enemies, allies = parse_input("ENNEMIS", "enemy"), parse_input("ALLIÉS", "ally")
    out = input("\nFichier export (defaut: analyse.md) > ").strip() or "analyse.md"
    depth = int(input("Profondeur > "))
    
    score, tpsMax, engine = 0, 0.0, SearchEngine()
    
    while score < 1000:
        depth += 1
        st = GameState()
        
        # Initialisation du plateau et de self.team_counts
        for pos, p in enemies + allies: 
            st.board[pos] = p
            st.team_counts[p['team']] += 1
            
        st.init_hash() 
        
        t0 = time.time()
        score, tree = engine.find_winning_sequence(st, depth, -float('inf'), float('inf'), True)
        tpsMax += time.time() - t0
        
        print(f"Profondeur={depth} | Eval={score} | Noeuds={engine.nodes} | Tps={tpsMax:.1f}s (Total={time.time() - t0})")

        with open(out, 'w', encoding='utf-8') as f:
            f.write(f"# Guide (Profondeur {depth})\n⏱️ {tpsMax:.1f}s | 🧠 Noeuds: {engine.nodes}\n\n")
            if score >= 1000:
                f.write("## 🏆 >>> VICTOIRE GARANTIE <<<\n\n")
            elif score <= -1000:
                f.write("## ⚠️ >>> DÉFAITE DÉTECTÉE <<<\n\n")
            else:
                f.write("## 📌 >>> Victoire incertaine <<<\n\n")
            f.write(generate_markdown_from_tree(tree))
        print("sauvé en .md")
            
        if score >= 1000 or score <= -1000: break

if __name__ == "__main__":
    main()