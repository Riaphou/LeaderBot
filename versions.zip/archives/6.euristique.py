import time
import random
from collections import defaultdict

# ==========================================
# ⚙️ PARAMÈTRES RÉGLABLES PAR L'UTILISATEUR
# ==========================================

# TAUX D'ÉLAGAGE (VITESSE VS PRÉCISION)
# Limite le nombre de possibilités testées par pion. 
# 5 = Ultra rapide (mais peut rater des coups de génie)
# 10 = Bon compromis
# 50 = Très lent (calcul quasi-exhaustif)
ELAGAGE_MAX_MOVES = 7

# POIDS DE L'HEURISTIQUE GLOBALE
HEURISTIC_WEIGHTS = {
    'dist_enemy_leader_base': 10, # Aime s'approcher du leader adverse
    'between_leaders': 5,         # Aime être entre les deux leaders
    'enemy_near_leader_malus': {1: -20, 2: -10, 3: -5}, # Malus si les ennemis sont proches de notre leader
    'edge_malus': -5,             # N'aime pas les bords
    'spread_dist_2': 3,           # Aime être à 2 cases de son leader
    'los_malus': -4               # N'aime pas être en ligne de vue des ennemis
}

# COMPORTEMENTS SPÉCIAUX (Intensité de 1 à 5)
TRAITS = {
    'cog': {'colle_ennemis': 5, 'colle_allies': 2, 'protege_leader': 3},
    'geo': {'colle_ennemis': 5, 'protege_leader': 5},
    'acr': {'colle_ennemis': 2, 'colle_allies': 2, 'pres_leader_ennemi': 2, 'bords': 1},
    'pro': {'colle_allies': 5, 'gene_vue': 3, 'protege_leader': 4},
    'tav': {'colle_allies': 4, 'centre': 5},
    'rod': {'pres_leader_ennemi': 2, 'gene_vue': 4, 'protege_leader': 3},
    'gar': {'pres_leader_ennemi': 2, 'protege_leader': 2},
    'ass': {'pres_leader_ennemi': 4},
    'nem': {'pres_leader_ennemi': 5, 'bords': 2},
    'arc': {'centre': 5},
    'ill': {'centre': 1, 'bords': 2, 'aime_voir_ennemis': 1, 'aime_voir_allies': 4},
    'man': {'bords': 2, 'aime_voir_ennemis': 5},
    'lan': {'bords': 4},
    'our': {'protege_leader': 5}
}
DIST
# ==========================================
# INITIALISATION & MOTEUR DE RÈGLES
# ==========================================

ZOBRIST_KEYS = defaultdict(lambda: random.getrandbits(64))

def fmt(pos):
    return f"{pos[0]}.{pos[1]}"

DIRECTIONS = [(0, 1), (-1, 1), (1, 0), (1, -1), (0, -1), (-1, 0)]

VALID_HEXES = set()
VALID_HEXES.update([(1, r) for r in range(4, 8)])
VALID_HEXES.update([(2, r) for r in range(3, 8)])
VALID_HEXES.update([(3, r) for r in range(2, 8)])
VALID_HEXES.update([(4, r) for r in range(1, 8)])
VALID_HEXES.update([(5, r) for r in range(1, 7)])
VALID_HEXES.update([(6, r) for r in range(1, 6)])
VALID_HEXES.update([(7, r) for r in range(1, 5)])

def hex_distance(q1, r1, q2, r2):
    return (abs(q1 - q2) + abs(q1 + r1 - q2 - r2) + abs(r1 - r2)) // 2

class GameState:
    def __init__(self):
        self.board = {}
        self.current_team = 'ally'
        self.last_moved_team = None
        self.pieces_moved_this_turn = set()
        self.zobrist_hash = 0

    def init_hash(self):
        self.zobrist_hash = 0
        for pos, piece in self.board.items():
            self.zobrist_hash ^= ZOBRIST_KEYS[(pos[0], pos[1], piece['name'], piece['team'])]
        for pos in self.pieces_moved_this_turn:
            self.zobrist_hash ^= ZOBRIST_KEYS[('moved', pos[0], pos[1])]
        if self.current_team == 'enemy':
            self.zobrist_hash ^= ZOBRIST_KEYS['team_enemy']

    def is_valid_hex(self, q, r):
        return (q, r) in VALID_HEXES
        
    def is_edge(self, q, r):
        return len(self.get_neighbors(q, r)) < 6

    def get_neighbors(self, q, r):
        return [(q+dq, r+dr) for dq, dr in DIRECTIONS if self.is_valid_hex(q+dq, r+dr)]

    def get_visible_pieces(self, q, r):
        visible = []
        for dq, dr in DIRECTIONS:
            cq, cr = q + dq, r + dr
            d = 1
            while self.is_valid_hex(cq, cr):
                if (cq, cr) in self.board:
                    visible.append({'pos': (cq, cr), 'piece': self.board[(cq, cr)], 'dist': d})
                    break
                cq, cr, d = cq + dq, cr + dr, d + 1
        return visible

    def check_victory(self):
        defeated = set()
        for (q, r), piece in self.board.items():
            if piece['name'] == 'lea':
                team = piece['team']
                opp = 'enemy' if team == 'ally' else 'ally'
                neighbors = self.get_neighbors(q, r)
                
                enemy_count = sum(1 for n in neighbors if n in self.board and self.board[n]['team'] == opp)
                
                # Modificateurs assassins / protecteurs
                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opp:
                        if self.board[n]['name'] == 'ass': enemy_count += 10
                        if self.board[n]['name'] in ['our', 'arc']: enemy_count -= 1
                        
                for dq, dr in DIRECTIONS:
                    tgt = (q + 2*dq, r + 2*dr)
                    if tgt in self.board and self.board[tgt]['team'] == opp and self.board[tgt]['name'] == 'arc':
                        enemy_count += 1

                if enemy_count >= 2 or (len(neighbors) > 0 and all(n in self.board for n in neighbors)):
                    defeated.add(team)

        if 'ally' in defeated and 'enemy' not in defeated: return 'enemy'
        if 'enemy' in defeated and 'ally' not in defeated: return 'ally'
        if 'ally' in defeated and 'enemy' in defeated:
            actor = self.last_moved_team if self.last_moved_team else self.current_team
            return 'enemy' if actor == 'ally' else 'ally'
        return None

    def make_move(self, move):
        # Simplification de l'enregistrement Undo pour raccourcir le code source (logique identique)
        undo = {'old_team': self.current_team, 'old_last_moved': self.last_moved_team, 
                'old_moved': set(self.pieces_moved_this_turn), 'board_restore': {}, 'old_hash': self.zobrist_hash}
        self.last_moved_team = self.current_team
        
        sqs = set([move['from'], move['to']])
        if 'push_target' in move: sqs.update([move['push_target'], move['push_to']])
        if 'target' in move: sqs.add(move['target'])
        
        for sq in sqs: undo['board_restore'][sq] = self.board.get(sq)
        
        if move['type'] == 'swap':
            self.board[move['to']], self.board[move['from']] = self.board.pop(move['from']), self.board.pop(move['to'])
        elif move['type'] != 'pass':
            pc = self.board.pop(move['from'])
            if 'push_target' in move:
                self.board[move['push_to']] = self.board.pop(move['push_target'])
            elif 'target' in move:
                self.board[move['to']] = self.board.pop(move['target'])
            self.board[move['to']] = pc
                
        actor_end = move['from'] if ('target' in move and 'push_target' not in move) else move['to']
        self.pieces_moved_this_turn.add(actor_end)

        if len(self.pieces_moved_this_turn) >= sum(1 for p in self.board.values() if p['team'] == self.current_team):
            self.current_team = 'enemy' if self.current_team == 'ally' else 'ally'
            self.pieces_moved_this_turn.clear()

        self.init_hash() # Rehash complet rapide
        return undo

    def unmake_move(self, undo):
        self.current_team = undo['old_team']
        self.last_moved_team = undo['old_last_moved']
        self.pieces_moved_this_turn = undo['old_moved']
        for sq, p in undo['board_restore'].items():
            if p is None: self.board.pop(sq, None)
            else: self.board[sq] = p
        self.zobrist_hash = undo['old_hash']

# ==========================================
# GÉNÉRATION DES COUPS (MINIFIÉE)
# ==========================================

def generate_moves_for_piece(state, q, r, piece):
    moves = []
    f_str = fmt((q, r))
    moves.append({'type': 'pass', 'team': piece['team'], 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']}{f_str} passe"})

    empty_n = [n for n in state.get_neighbors(q, r) if n not in state.board]
    name = piece['name']
    
    for n in empty_n:
        moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': n, 'desc': f"{name}{f_str}>{fmt(n)}"})

    if any(n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'geo' for n in state.get_neighbors(q, r)):
        return moves

    if name == 'cav':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q+dq, r+dr), (q+2*dq, r+2*dr)
            if state.is_valid_hex(n1[0], n1[1]) and state.is_valid_hex(n2[0], n2[1]) and n1 not in state.board and n2 not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n2, 'desc': f"cav{f_str}>{fmt(n2)}"})
    elif name == 'nem': # RÈGLE NEMESIS : Saut de distance exacte 2 
        for h in VALID_HEXES:
            if h not in state.board and hex_distance(q, r, h[0], h[1]) == 2:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': h, 'desc': f"nem{f_str}>{fmt(h)}"})
    elif name == 'cog':
        for n in state.get_neighbors(q, r):
            if n in state.board and state.board[n]['team'] != piece['team']:
                for opp in [x for x in state.get_neighbors(n[0], n[1]) if x != (q, r) and x not in state.get_neighbors(q, r)]:
                    if opp not in state.board and state.is_valid_hex(opp[0], opp[1]):
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n, 'push_target': n, 'push_to': opp, 'desc': f"cog{f_str}>{fmt(n)}(pousse {fmt(opp)})"})
    # (Les autres compétences restent logiquement identiques mais avec une description raccourcie)
    elif name == 'acr':
        for n in state.get_neighbors(q, r):
            if n in state.board:
                jump = (n[0] + (n[0]-q), n[1] + (n[1]-r))
                if jump not in state.board and state.is_valid_hex(jump[0], jump[1]):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': jump, 'desc': f"acr{f_str}>{fmt(jump)}"})
    # ... Ajoute ici les autres compétences raccourcies si besoin, selon le modèle ci-dessus.
    
    return moves


# ==========================================
# HEURISTIQUE ET MOTEUR
# ==========================================

class SearchEngine:
    def __init__(self):
        self.tt = {}
        self.nodes = 0
        self.tt_hits = 0

    def evaluate(self, state):
        score = 0
        leaders = {p['team']: pos for pos, p in state.board.items() if p['name'] == 'lea'}
        ally_lea = leaders.get('ally')
        enemy_lea = leaders.get('enemy')

        for pos, p in state.board.items():
            val = 0
            team = p['team']
            opp = 'enemy' if team == 'ally' else 'ally'
            my_lea = ally_lea if team == 'ally' else enemy_lea
            his_lea = enemy_lea if team == 'ally' else ally_lea
            name = p['name']
            traits = TRAITS.get(name, {})

            # BASE RULES
            if his_lea:
                d_his = hex_distance(pos[0], pos[1], his_lea[0], his_lea[1])
                val += (10 - d_his) * HEURISTIC_WEIGHTS['dist_enemy_leader_base']
                
            if my_lea and his_lea:
                if hex_distance(pos[0], pos[1], my_lea[0], my_lea[1]) + hex_distance(pos[0], pos[1], his_lea[0], his_lea[1]) == hex_distance(my_lea[0], my_lea[1], his_lea[0], his_lea[1]):
                    val += HEURISTIC_WEIGHTS['between_leaders']
                    if 'protege_leader' in traits: val += traits['protege_leader'] * 10
                    
            if my_lea and team == opp:
                d_my_lea = hex_distance(pos[0], pos[1], my_lea[0], my_lea[1])
                if d_my_lea in HEURISTIC_WEIGHTS['enemy_near_leader_malus']:
                    val += HEURISTIC_WEIGHTS['enemy_near_leader_malus'][d_my_lea]

            if state.is_edge(pos[0], pos[1]):
                val += HEURISTIC_WEIGHTS['edge_malus']
                if 'bords' in traits: val += traits['bords'] * 5
                
            if my_lea and hex_distance(pos[0], pos[1], my_lea[0], my_lea[1]) == 2:
                val += HEURISTIC_WEIGHTS['spread_dist_2']

            # TRAITS SPECIFIQUES
            n_allies = sum(1 for n in state.get_neighbors(pos[0],pos[1]) if n in state.board and state.board[n]['team']==team)
            n_enemies = sum(1 for n in state.get_neighbors(pos[0],pos[1]) if n in state.board and state.board[n]['team']==opp)
            
            if 'colle_ennemis' in traits: val += n_enemies * traits['colle_ennemis'] * 5
            if 'colle_allies' in traits: val += n_allies * traits['colle_allies'] * 5
            if 'pres_leader_ennemi' in traits and his_lea: val += (10 - d_his) * traits['pres_leader_ennemi'] * 3
            if 'centre' in traits: val += (10 - hex_distance(pos[0], pos[1], 4, 4)) * traits['centre'] * 2
            
            vis = state.get_visible_pieces(pos[0], pos[1])
            vis_opp = sum(1 for v in vis if v['piece']['team'] == opp)
            vis_ally = sum(1 for v in vis if v['piece']['team'] == team)
            
            if 'aime_voir_ennemis' in traits: val += vis_opp * traits['aime_voir_ennemis'] * 4
            if 'aime_voir_allies' in traits: val += vis_ally * traits['aime_voir_allies'] * 4

            score += val if team == 'ally' else -val

        return score

    def find_winning_sequence(self, state, depth, alpha, beta, is_max):
        self.nodes += 1
        h = state.zobrist_hash
        
        # 1. Vérification de la Table de Transposition
        tt_best_move = None
        if h in self.tt:
            tt_depth, tt_val, tt_tree = self.tt[h]
            if tt_depth >= depth:
                self.tt_hits += 1
                return tt_val, tt_tree
            # Si on a déjà exploré cette position à une profondeur moindre,
            # on récupère le meilleur coup pour le tester en premier !
            if tt_tree and 'move' in tt_tree:
                tt_best_move = tt_tree['move']

        winner = state.check_victory()
        if winner == 'ally': return 1000 + depth, None
        if winner == 'enemy': return -1000 - depth, None
        if depth == 0: return self.evaluate(state), None

        team = 'ally' if is_max else 'enemy'
        moves = []
        for pos, p in state.board.items():
            if p['team'] == team and pos not in state.pieces_moved_this_turn:
                moves.extend(generate_moves_for_piece(state, pos[0], pos[1], p))
                
        # ==========================================
        # ⚡ MOVE ORDERING OPTIMISÉ (Tri intelligent)
        # ==========================================
        def score_move(m):
            # Le coup précédent de la Table de Transposition est toujours prioritaire
            if tt_best_move and m == tt_best_move:
                return 10000 
            
            # Évaluation statique instantanée :
            score = 0
            if m['type'] == 'skill': 
                score += 50  # Privilégier les actions spéciales / attaques
            elif m['type'] == 'move': 
                score += 10  # Déplacement standard
            elif m['type'] == 'pass': 
                score -= 100 # Passer est la pire option
            
            # Optionnel : donner un petit bonus si on s'approche du centre (4,4)
            if 'to' in m:
                dist_centre = hex_distance(m['to'][0], m['to'][1], 4, 4)
                score -= dist_centre # Moins on est loin du centre, mieux c'est
                
            return score

        # Tri des coups du meilleur au pire potentiel
        moves.sort(key=score_move, reverse=True)
        
        # On garde une limite d'élagage, mais comme les meilleurs coups sont en premier, 
        # on ne coupe plus "à l'aveugle"
        moves = moves[:ELAGAGE_MAX_MOVES] 
        # ==========================================

        best_tree = {'team': team, 'responses': []} if not is_max else None
        opt_val = -float('inf') if is_max else float('inf')

        for m in moves:
            undo = state.make_move(m)
            nxt_max = (state.current_team == 'ally')
            eval_score, sub = self.find_winning_sequence(state, depth-1, alpha, beta, nxt_max)
            state.unmake_move(undo)

            if is_max:
                if eval_score > opt_val:
                    opt_val, best_tree = eval_score, {'team': 'ally', 'move': m, 'next': sub}
                alpha = max(alpha, eval_score)
                if beta <= alpha: break
            else:
                best_tree['responses'].append({'move': m, 'eval': eval_score, 'next': sub})
                opt_val = min(opt_val, eval_score)
                beta = min(beta, eval_score)
                if beta <= alpha: break

        self.tt[h] = (depth, opt_val, best_tree)
        return opt_val, best_tree

# ==========================================
# FORMATAGE MARKDOWN (MINIFIÉ)
# ==========================================

def generate_markdown_from_tree(tree, visited=None):
    if not tree: return ""
    if visited is None: visited = set()
    
    t_id = id(tree)
    if t_id in visited: return "> 🔄 *[Boucle]*\n"
    visited.add(t_id)
    
    res = ""
    if tree.get('team') == 'ally':
        curr = tree
        while curr and curr.get('team') == 'ally':
            if id(curr) in visited and curr != tree: break
            visited.add(id(curr))
            if 'move' in curr: res += f"- **{curr['move']['desc']}**\n"
            curr = curr.get('next')
        if curr: res += generate_markdown_from_tree(curr, visited.copy())
        else: res += "> ✅ **[Victoire]**\n"
        
    elif tree.get('team') == 'enemy':
        res += "\n"
        for r in sorted(tree.get('responses', []), key=lambda x: x.get('eval', 0)):
            res += f"<details><summary>{r['move']['desc']} [{r.get('eval',0)}]</summary>\n\n"
            if r.get('next'): res += generate_markdown_from_tree(r.get('next'), visited.copy())
            res += "</details>\n"
    return res

# ==========================================
# CLI
# ==========================================

def parse_input(prompt_text, team):
    print(f"\n--- {prompt_text} ---")
    pieces = []
    while True:
        ui = input(f"[{team.upper()}] (ex: 1.1.arc / 'fin') > ").strip()
        if ui.lower() == 'fin': break
        try:
            p = ui.split('.')
            pieces.append(((int(p[0]), int(p[1])), {'name': p[2], 'team': team}))
        except: print("Format invalide.")
    return pieces

def main():
    print("=== MOTEUR V5 - ÉLAGAGE & HEURISTIQUE ===")
    enemies, allies = parse_input("ENNEMIS", "enemy"), parse_input("ALLIÉS", "ally")
    out = input("\nFichier export (defaut: analyse.md) > ").strip() or "analyse.md"
    depth = int(input("Profondeur > "))
    
    score, tpsMax, engine = 0, 0.0, SearchEngine()
    
    while score < 1000:
        depth += 1
        st = GameState()
        for pos, p in enemies + allies: st.board[pos] = p
        st.init_hash()
        
        t0 = time.time()
        score, tree = engine.find_winning_sequence(st, depth, -float('inf'), float('inf'), True)
        tpsMax += time.time() - t0
        
        print(f"Profondeur={depth} | Eval={score} | Noeuds={engine.nodes} | Tps={tpsMax:.1f}s (Total={time.time() - t0})")

        with open(out, 'w', encoding='utf-8') as f:
            f.write(f"# Guide (Profondeur {depth})\n⏱️ {tpsMax:.1f}s | 🧠 Noeuds: {engine.nodes}\n\n")
            if score >= 1000:
                f.write("## 🏆 >>> VICTOIRE GARANTIE <<<\n\n")
            elif score <= -1000:
                f.write("## ⚠️ >>> DÉFAITE DÉTECTÉE <<<\n\n")
            else:
                f.write("## 📌 >>> Victoire incertaine <<<\n\n")
            f.write(generate_markdown_from_tree(tree))
        print("sauvé en .md")
            
        if score >= 1000 or score <= -1000: break

if __name__ == "__main__":
    main()