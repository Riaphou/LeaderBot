import time
import random
from collections import defaultdict



# --- ZOBRIST HASHING INITIALISATION ---

def generate_random_64():
    return random.getrandbits(64)

ZOBRIST_KEYS = defaultdict(generate_random_64)

# --- MOTEUR DE TRADUCTION DES COORDONNÉES ---

def to_user_coords(q, r):
    return q, r

def from_user_coords(q_user, r_user):
    return q_user, r_user

def fmt(pos):
    return str(to_user_coords(pos[0], pos[1]))

# --- MOTEUR DE RÈGLES ---

DIRECTIONS = [
    (0, 1), (-1, 1), (1, 0), (1, -1), (0, -1), (-1, 0)
]

VALID_HEXES = set()
VALID_HEXES.update([(1, r) for r in range(4, 8)])
VALID_HEXES.update([(2, r) for r in range(3, 8)])
VALID_HEXES.update([(3, r) for r in range(2, 8)])
VALID_HEXES.update([(4, r) for r in range(1, 8)])
VALID_HEXES.update([(5, r) for r in range(1, 7)])
VALID_HEXES.update([(6, r) for r in range(1, 6)])
VALID_HEXES.update([(7, r) for r in range(1, 5)])

def hex_distance(q1, r1, q2, r2):
    return (abs(q1 - q2) + abs(q1 + r1 - q2 - r2) + abs(r1 - r2)) // 2

class GameState:
    def __init__(self):
        self.board = {}
        self.current_team = 'ally'
        self.last_moved_team = None
        self.pieces_moved_this_turn = set()
        self.zobrist_hash = 0

    def init_hash(self):
        self.zobrist_hash = 0
        for pos, piece in self.board.items():
            self._toggle_piece(pos, piece)
        for pos in self.pieces_moved_this_turn:
            self._toggle_moved(pos)
        if self.current_team == 'enemy':
            self._toggle_team()

    def _toggle_piece(self, sq, piece):
        if piece is not None:
            self.zobrist_hash ^= ZOBRIST_KEYS[(sq[0], sq[1], piece['name'], piece['team'])]

    def _toggle_moved(self, sq):
        self.zobrist_hash ^= ZOBRIST_KEYS[('moved', sq[0], sq[1])]

    def _toggle_team(self):
        self.zobrist_hash ^= ZOBRIST_KEYS['team_enemy']

    def state_hash(self):
        return self.zobrist_hash

    def is_valid_hex(self, q, r):
        return (q, r) in VALID_HEXES

    def get_neighbors(self, q, r):
        return [(q+dq, r+dr) for dq, dr in DIRECTIONS if self.is_valid_hex(q+dq, r+dr)]

    def get_visible_pieces(self, q, r):
        visible = []
        for dq, dr in DIRECTIONS:
            cq, cr = q + dq, r + dr
            dist = 1
            while self.is_valid_hex(cq, cr):
                if (cq, cr) in self.board:
                    visible.append({
                        'pos': (cq, cr), 
                        'piece': self.board[(cq, cr)], 
                        'dir': (dq, dr), 
                        'dist': dist
                    })
                    break
                cq += dq
                cr += dr
                dist += 1
        return visible

    def can_be_moved_by_enemy_skill(self, pos, team):
        if self.board[pos]['name'] == 'pro':
            return False
        for n in self.get_neighbors(pos[0], pos[1]):
            if n in self.board and self.board[n]['team'] == team and self.board[n]['name'] == 'pro':
                return False
        return True

    def check_victory(self):
        defeated_teams = set()

        for (q, r), piece in self.board.items():
            if piece['name'] == 'lea':
                team = piece['team']
                opposing_team = 'enemy' if team == 'ally' else 'ally'
                
                neighbors = self.get_neighbors(q, r)
                
                enemy_count = 0
                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opposing_team:
                        enemy_count += 1
                        if self.board[n]['name'] == 'ass':
                            enemy_count += 10
                        if self.board[n]['name'] in ['our', 'arc']:
                            enemy_count -= 1
                
                # VÉRIFICATION DE L'ARCHÈRE : Exactement 2 cases en ligne droite (ignore les obstacles)
                for dq, dr in DIRECTIONS:
                    target_hex = (q + 2 * dq, r + 2 * dr)
                    if target_hex in self.board:
                        p = self.board[target_hex]
                        if p['team'] == opposing_team and p['name'] == 'arc':
                            enemy_count += 1

                # Condition d'élimination du Leader (menacé ou encerclé)
                if enemy_count >= 2 or (len(neighbors) > 0 and all(n in self.board for n in neighbors)):
                    defeated_teams.add(team)

        # Arbitrage des victoires / défaites
        if 'ally' in defeated_teams and 'enemy' not in defeated_teams:
            return 'enemy'
        if 'enemy' in defeated_teams and 'ally' not in defeated_teams:
            return 'ally'
        if 'ally' in defeated_teams and 'enemy' in defeated_teams:
            # En cas de double élimination (suicide/égalité), l'auteur du coup PERD immédiatement
            actor = self.last_moved_team if self.last_moved_team else self.current_team
            return 'enemy' if actor == 'ally' else 'ally'

        return None

    def make_move(self, move):
        undo_info = {
            'old_team': self.current_team,
            'old_last_moved': self.last_moved_team,
            'old_moved': set(self.pieces_moved_this_turn),
            'board_restore': {},
            'old_hash': self.zobrist_hash
        }
        self.last_moved_team = self.current_team
        
        squares_to_touch = set()
        if move['type'] == 'swap':
            squares_to_touch.update([move['from'], move['to']])
        elif move['type'] != 'pass':
            squares_to_touch.update([move['from'], move['to']])
            if 'push_target' in move: squares_to_touch.update([move['push_target'], move['push_to']])
            if 'target' in move: squares_to_touch.add(move['target'])
            
        for sq in squares_to_touch:
            undo_info['board_restore'][sq] = self.board.get(sq)

        # 1. RETRAIT DU HASH (État avant le mouvement)
        for sq in squares_to_touch:
            self._toggle_piece(sq, self.board.get(sq))
        for sq in self.pieces_moved_this_turn:
            self._toggle_moved(sq)
        if self.current_team == 'enemy':
            self._toggle_team()

        # 2. SUIVI DYNAMIQUE DES DÉPLACEMENTS (Fait voyager le statut "a joué")
        new_moved_turn = set()
        for sq in self.pieces_moved_this_turn:
            new_sq = sq
            if move['type'] == 'swap':
                if sq == move['from']: new_sq = move['to']
                elif sq == move['to']: new_sq = move['from']
            elif move['type'] != 'pass':
                if 'push_target' in move and sq == move['push_target']:
                    new_sq = move['push_to']
                elif 'target' in move and sq == move['target']:
                    new_sq = move['to']
            new_moved_turn.add(new_sq)
        self.pieces_moved_this_turn = new_moved_turn

        # 3. MANIPULATION DU PLATEAU
        if move['type'] == 'swap':
            p1, p2 = self.board.pop(move['from']), self.board.pop(move['to'])
            self.board[move['to']], self.board[move['from']] = p1, p2
        elif move['type'] != 'pass':
            piece = self.board.pop(move['from'])
            if 'push_target' in move:
                self.board[move['push_to']] = self.board.pop(move['push_target'])
                self.board[move['to']] = piece
            elif 'target' in move:
                self.board[move['to']] = self.board.pop(move['target'])
                self.board[move['from']] = piece
            else:
                self.board[move['to']] = piece
                
        # 4. LE PION ACTIF CONSOMME SON ACTION
        actor_end_pos = move['from'] if ('target' in move and 'push_target' not in move) else move['to']
        self.pieces_moved_this_turn.add(actor_end_pos)

        # 5. VÉRIFICATION DE FIN DE TOUR
        ally_count = sum(1 for p in self.board.values() if p['team'] == self.current_team)
        if len(self.pieces_moved_this_turn) >= ally_count:
            self.current_team = 'enemy' if self.current_team == 'ally' else 'ally'
            self.pieces_moved_this_turn.clear()

        # 6. INJECTION DANS LE HASH (État après le mouvement)
        for sq in squares_to_touch:
            self._toggle_piece(sq, self.board.get(sq))
        for sq in self.pieces_moved_this_turn:
            self._toggle_moved(sq)
        if self.current_team == 'enemy':
            self._toggle_team()

        return undo_info

    def unmake_move(self, undo_info):
        self.current_team = undo_info['old_team']
        self.last_moved_team = undo_info['old_last_moved']
        self.pieces_moved_this_turn = undo_info['old_moved']
        for sq, piece in undo_info['board_restore'].items():
            if piece is None:
                self.board.pop(sq, None)
            else:
                self.board[sq] = piece
        self.zobrist_hash = undo_info['old_hash']


def generate_moves_for_piece(state, q, r, piece):
    moves = []
    from_str = fmt((q, r))
    moves.append({'type': 'pass', 'team': piece['team'], 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']} en {from_str} maintient sa position"})

    neighbors = state.get_neighbors(q, r)
    empty_neighbors = [n for n in neighbors if n not in state.board]
    has_viz = any(p['name'] == 'viz' and p['team'] == piece['team'] for p in state.board.values())
    name = piece['name']
    
    for n in empty_neighbors:
        moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': n, 'desc': f"{name} en {from_str} avance furtivement en {fmt(n)}"})
        if name == 'lea' and has_viz:
            for sn in state.get_neighbors(n[0], n[1]):
                if sn not in state.board and sn != (q, r):
                    moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': sn, 'desc': f"lea en {from_str} (Porté par les vents du viz) bondit vers {fmt(sn)}"})

    if any(n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'geo' for n in neighbors):
        return moves

    if name == 'cav':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q + dq, r + dr), (q + 2*dq, r + 2*dr)
            if state.is_valid_hex(n1[0], n1[1]) and state.is_valid_hex(n2[0], n2[1]) and n1 not in state.board and n2 not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n2, 'desc': f"cav en {from_str} charge violemment en {fmt(n2)}"})

    elif name == 'gar':
        lea_pos = next((pos for pos, p in state.board.items() if p['name'] == 'lea' and p['team'] == piece['team']), None)
        if lea_pos:
            teleport_hexes = [ln for ln in state.get_neighbors(lea_pos[0], lea_pos[1]) if ln not in state.board or ln == (q, r)]
            for t_hex in teleport_hexes:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': t_hex, 'desc': f"gar en {from_str} se téléporte pour protéger le lea en {fmt(t_hex)}"})
                for final_hex in state.get_neighbors(t_hex[0], t_hex[1]):
                    if (final_hex not in state.board or final_hex == (q, r)) and final_hex != t_hex:
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': final_hex, 'desc': f"gar en {from_str} se déploie en {fmt(final_hex)} après téléportation près du lea"})

    elif name == 'tav':
        for n in neighbors:
            if n in state.board and state.board[n]['team'] == piece['team']:
                target_p = state.board[n]
                for tn in [x for x in state.get_neighbors(n[0], n[1]) if x not in state.board and x != (q, r)]:
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'target': n, 'to': tn, 'desc': f"tav en {from_str} bouscule amicalement {target_p['name']} en {fmt(n)} vers {fmt(tn)}"})

    elif name == 'acr':
        for n in state.get_neighbors(q, r):
            if n in state.board:
                obstacle_p = state.board[n]
                jump1 = (n[0] + (n[0] - q), n[1] + (n[1] - r))
                if jump1 not in state.board and state.is_valid_hex(jump1[0], jump1[1]):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': jump1, 'desc': f"acr en {from_str} voltige par-dessus {obstacle_p['name']} en {fmt(n)} jusqu'en {fmt(jump1)}"})

    elif name == 'cog':
        for n in state.get_neighbors(q, r):
            if n in state.board and state.board[n]['team'] != piece['team']:
                target_p = state.board[n]
                my_neighbors = state.get_neighbors(q, r)
                opposite_hexes = [opp for opp in state.get_neighbors(n[0], n[1]) if opp != (q, r) and opp not in my_neighbors]
                for push_hex in opposite_hexes:
                    if push_hex not in state.board and state.is_valid_hex(push_hex[0], push_hex[1]):
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n, 'push_target': n, 'push_to': push_hex, 'desc': f"cog en {from_str} fracasse {target_p['name']} en {fmt(n)} vers {fmt(push_hex)} et prend sa place en {fmt(n)}"})

    elif name == 'rod':
        for h in VALID_HEXES:
            if h not in state.board:
                if not any(hn in state.board and state.board[hn]['team'] != piece['team'] for hn in state.get_neighbors(h[0], h[1])):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': h, 'desc': f"rod en {from_str} se fond dans les ombres et réapparaît en {fmt(h)}"})

    elif name == 'lan':
        for vis in state.get_visible_pieces(q, r):
            t_pos, t_piece, (dq, dr) = vis['pos'], vis['piece'], vis['dir']
            land_q, land_r = t_pos[0] - dq, t_pos[1] - dr
            if (land_q, land_r) != (q, r) and state.is_valid_hex(land_q, land_r) and (land_q, land_r) not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': (land_q, land_r), 'desc': f"lan en {from_str} se tracte vers {fmt(t_pos)} et atterrit en {fmt((land_q, land_r))}"})
            pull_q, pull_r = q + dq, r + dr
            if (pull_q, pull_r) != t_pos and state.is_valid_hex(pull_q, pull_r) and (pull_q, pull_r) not in state.board:
                if t_piece['team'] == piece['team'] or state.can_be_moved_by_enemy_skill(t_pos, t_piece['team']):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'target': t_pos, 'to': (pull_q, pull_r), 'desc': f"lan en {from_str} ferre {t_piece['name']} en {fmt(t_pos)} et le ramène en {fmt((pull_q, pull_r))}"})

    elif name == 'ill':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1:
                moves.append({'type': 'swap', 'team': piece['team'], 'from': (q, r), 'to': vis['pos'], 'desc': f"ill en {from_str} altère la réalité et échange de place avec {vis['piece']['name']} en {fmt(vis['pos'])}"})

    elif name == 'man':
        # Condition : Ennemis uniquement (team != piece['team']) ET non adjacents (dist > 1)
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1 and vis['piece']['team'] != piece['team'] and state.can_be_moved_by_enemy_skill(vis['pos'], vis['piece']['team']):
                for tn in state.get_neighbors(vis['pos'][0], vis['pos'][1]):
                    if tn not in state.board:
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'target': vis['pos'], 'to': tn, 'desc': f"man en {from_str} force l'esprit de {vis['piece']['name']} en {fmt(vis['pos'])} à marcher vers {fmt(tn)}"})

    return moves


# --- MOTEUR DE RECHERCHE OPTIMISÉ ---

class SearchEngine:
    def __init__(self):
        self.tt = {}
        self.killer_moves = {}
        self.nodes_explored = 0
        self.tt_hits = 0

    def store_killer_move(self, depth, move):
        if depth not in self.killer_moves:
            self.killer_moves[depth] = []
        if move not in self.killer_moves[depth]:
            self.killer_moves[depth].insert(0, move)
            self.killer_moves[depth] = self.killer_moves[depth][:2]

    def sort_moves_heuristically(self, state, moves, maximizing_player, depth):
        target_team = 'enemy' if maximizing_player else 'ally'
        lea_pos = next((pos for pos, p in state.board.items() if p['name'] == 'lea' and p['team'] == target_team), None)
        
        killers = self.killer_moves.get(depth, [])

        def move_score(move):
            if move['type'] == 'pass': return 999 
            score = 0
            if move in killers:
                score -= 1000 
            if lea_pos:
                main_to_pos = move.get('push_to') or move['to']
                score += hex_distance(main_to_pos[0], main_to_pos[1], lea_pos[0], lea_pos[1])
            return score

        return sorted(moves, key=move_score)

    def get_all_possible_moves(self, state, team):
        all_moves = []
        for pos, piece in state.board.items():
            if piece['team'] == team and pos not in state.pieces_moved_this_turn:
                all_moves.extend(generate_moves_for_piece(state, pos[0], pos[1], piece))
        return all_moves

    def find_winning_sequence(self, state, depth, alpha, beta, maximizing_player):
        self.nodes_explored += 1
        
        state_h = state.state_hash()
        if state_h in self.tt:
            tt_depth, tt_score, tt_tree = self.tt[state_h]
            if tt_depth >= depth:
                self.tt_hits += 1
                return tt_score, tt_tree

        winner = state.check_victory()
        if winner == 'ally':
            return 100 + depth, None
        elif winner == 'enemy':
            return -100 - depth, None
        if depth == 0:
            return 0, None

        current_team = 'ally' if maximizing_player else 'enemy'
        moves = self.get_all_possible_moves(state, current_team)
        moves = self.sort_moves_heuristically(state, moves, maximizing_player, depth)

        if maximizing_player:
            max_eval = -float('inf')
            best_tree = None
            for move in moves:
                undo_info = state.make_move(move)
                next_is_max = (state.current_team == 'ally')
                
                eval_score, sub_tree = self.find_winning_sequence(state, depth - 1, alpha, beta, next_is_max)
                state.unmake_move(undo_info)
                
                if eval_score > max_eval:
                    max_eval = eval_score
                    best_tree = {'team': 'ally', 'move': move, 'next': sub_tree}
                    
                alpha = max(alpha, eval_score)
                if beta <= alpha or max_eval >= 100:
                    self.store_killer_move(depth, move)
                    break
                    
            self.tt[state_h] = (depth, max_eval, best_tree)
            return max_eval, best_tree
            
        else:
            min_eval = float('inf')
            best_tree = {'team': 'enemy', 'responses': []}
            for move in moves:
                undo_info = state.make_move(move)
                next_is_max = (state.current_team == 'ally')
                
                eval_score, sub_tree = self.find_winning_sequence(state, depth - 1, alpha, beta, next_is_max)
                state.unmake_move(undo_info)
                
                best_tree['responses'].append({'move': move, 'eval': eval_score, 'next': sub_tree})
                
                if eval_score < min_eval:
                    min_eval = eval_score
                    
                beta = min(beta, eval_score)
                if beta <= alpha or min_eval <= -100:
                    self.store_killer_move(depth, move)
                    break
                    
            self.tt[state_h] = (depth, min_eval, best_tree)
            return min_eval, best_tree


# --- FORMATAGE INTERACTIF (MARKDOWN AVEC BALISES HTML <DETAILS>) ---

def generate_markdown_from_tree(tree, visited=None):
    if not tree:
        return ""

    if visited is None:
        visited = set()

    # Détection de boucle infinie dans l'arbre décisionnel
    tree_id = id(tree)
    if tree_id in visited:
        return "> 🔄 *[Repétition de position / Boucle détectée - Analyse arrêtée sur cette branche]*\n\n"
    
    visited.add(tree_id)
    res = ""

    if tree.get('team') == 'ally':
        curr = tree
        ally_moves = []
        
        while curr and curr.get('team') == 'ally':
            c_id = id(curr)
            if c_id in visited and curr != tree:
                break
            visited.add(c_id)
            
            if 'move' in curr and 'desc' in curr['move']:
                ally_moves.append(curr['move']['desc'])
            curr = curr.get('next')

        res += "### 🎯 À vous de jouer (Séquence recommandée) :\n"
        for i, am in enumerate(ally_moves, 1):
            res += f"1. **{am}**\n"
        res += "\n"

        if curr:
            res += generate_markdown_from_tree(curr, visited.copy())
        else:
            res += "> ✅ **[Victoire assurée]** Aucune défense ennemie ne peut stopper cette ligne.\n\n"

    elif tree.get('team') == 'enemy':
        responses = tree.get('responses', [])
        responses.sort(key=lambda x: x.get('eval', 0))

        res += "---osez explorer les ripostes ennemies ci-dessous---\n\n"
        for r in responses:
            m_desc = r['move']['desc']
            eval_score = r.get('eval', 0)
            nxt = r.get('next')
            
            res += f"<details>\n"
            res += f"<summary><b>Si l'adversaire joue :</b> {m_desc} <i>(Score: {eval_score})</i></summary>\n\n"
            
            if nxt:
                res += generate_markdown_from_tree(nxt, visited.copy())
            else:
                res += "> *Fin de la variante ou position stable.*\n"
                
            res += f"</details>\n\n"

    return res


# --- INTERFACE UTILISATEUR & CLI ---

def parse_input(prompt_text, team):
    print(f"\n--- {prompt_text} ---")
    print("Entrez les pions un par un sous la forme 'Colonne.Ligne.Nom' (q.r.nom). Tapez 'fin' pour terminer.")
    pieces = []
    while True:
        user_input = input(f"[{team.upper()}] Pion > ").strip()
        if user_input.lower() == 'fin':
            break
        try:
            parts = user_input.split('.')
            q_user, r_user, name = int(parts[0]), int(parts[1]), parts[2].strip()
            q, r = from_user_coords(q_user, r_user)
            pieces.append(((q, r), {'name': name, 'team': team}))
        except Exception:
            print("Erreur de format. Utilisez 'q.r.Nom' (ex: 1.1.arc).")
    return pieces

def main():
    print("=====================================================")
    print(" MOTEUR V4.2 - FIX DISAMBIGUATION & SINGLE MOVE RULE ")
    print("=====================================================")
    
    enemies = parse_input("POSITIONS ENNEMIES", "enemy")
    allies = parse_input("POSITIONS ALLIÉES", "ally")

    output_filename = input("\nNom du fichier d'export (ex: analyse.md) > ").strip()
    if not output_filename:
        output_filename = "analyse.md"
    
    if not output_filename.startswith(".\\"):
        output_filename = ".\\" + output_filename

    while True:
        try:
            max_depth = int(input("Profondeur tactique max de départ (ex: 10) > "))
            break
        except ValueError:
            print("Veuillez entrer un nombre entier.")

    score = 0
    engine = SearchEngine()
    
    tpsMax = 0.0
    while score < 100:
        max_depth += 1 
        print(f"\n[Simulation de {max_depth} actions successives...]")

        state = GameState()
        for pos, p in enemies + allies:
            state.board[pos] = p
            
        state.init_hash() 
            
        start_time = time.time()
        
        score, decision_tree = engine.find_winning_sequence(state, max_depth, -float('inf'), float('inf'), maximizing_player=True)
        
        end_time = time.time()

        tpsMax += end_time - start_time

        print(f"   Nœuds explorés : {engine.nodes_explored} | Temps : {end_time - start_time:.3f} s (Depuis début : {tpsMax:.3f}) | Éval = {score}")


        
        if score >= 100 or score <= -100:
            print("sauvegarde en Markdown...")
            with open(output_filename, 'w', encoding='utf-8') as f:
                f.write(f"# 🧭 Guide Stratégique Interactif (Profondeur {max_depth})\n\n")
                f.write(f"> *Cliquez sur les lignes de l'adversaire pour ouvrir/fermer chaque variante et éviter de vous perdre.*\n\n")
                f.write(f"- **Temps de calcul** : {tpsMax:.3f} s\n")
                f.write(f"- **Nœuds explorés** : {engine.nodes_explored}\n")
                f.write(f"- **Coups en cache (TT)** : {engine.tt_hits}\n\n---\n\n")
                
                if score >= 100:
                    f.write("## 🏆 >>> VICTOIRE TOTALE GARANTIE <<<\n\n")
                elif score <= -100:
                    f.write("## ⚠️ >>> DÉFAITE FORCÉE DÉTECTÉE <<<\n\n")
                else:
                    f.write("## 📌 >>> MEILLEURES MANŒUVRES TEMPORAIRES <<<\n\n")
                    
                f.write(generate_markdown_from_tree(decision_tree))
            print(f"-> Fichier '{output_filename}' mis à jour avec le format interactif.")

            print("\nRecherche terminée. Guide interactif final inscrit dans le fichier.")
            break

if __name__ == "__main__":
    main()