import copy

DIRECTIONS = [
    (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1)
]

VALID_HEXES = set()
VALID_HEXES.update([(0, 4)])
VALID_HEXES.update([(1, r) for r in range(2, 5)])
VALID_HEXES.update([(2, r) for r in range(1, 6)])
for q in range(3, 7):
    VALID_HEXES.update([(q, r) for r in range(0, 7)])

class GameState:
    def __init__(self):
        self.board = {}
        self.current_turn = 'ally'

    def is_valid_hex(self, q, r):
        return (q, r) in VALID_HEXES

    def get_neighbors(self, q, r):
        return [(q+dq, r+dr) for dq, dr in DIRECTIONS if self.is_valid_hex(q+dq, r+dr)]

    def get_visible_pieces(self, q, r):
        visible = []
        for dq, dr in DIRECTIONS:
            cq, cr = q + dq, r + dr
            dist = 1
            while self.is_valid_hex(cq, cr):
                if (cq, cr) in self.board:
                    visible.append({
                        'pos': (cq, cr), 
                        'piece': self.board[(cq, cr)], 
                        'dir': (dq, dr), 
                        'dist': dist
                    })
                    break
                cq += dq
                cr += dr
                dist += 1
        return visible

    def can_be_moved_by_enemy_skill(self, pos, team):
        if self.board[pos]['name'] == 'Protecteur':
            return False
        for n in self.get_neighbors(pos[0], pos[1]):
            if n in self.board and self.board[n]['team'] == team and self.board[n]['name'] == 'Protecteur':
                return False
        return True

    def check_victory(self):
        for (q, r), piece in self.board.items():
            if piece['name'] == 'Leader':
                team = piece['team']
                opposing_team = 'enemy' if team == 'ally' else 'ally'
                
                neighbors = self.get_neighbors(q, r)
                
                enemy_count = 0
                assassin_present = False

                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opposing_team:
                        enemy_count += 1
                        if self.board[n]['name'] == 'Assassin':
                            enemy_count += 10
                        if self.board[n]['name'] in ['Ourson', 'Archère']:
                            enemy_count -= 1
                
                # Vérification de l'Archère à exactement 2 cases en ligne droite
                for vis in self.get_visible_pieces(q, r):
                    if vis['dist'] == 2 and vis['piece']['team'] == opposing_team and vis['piece']['name'] == 'Archère':
                        enemy_count += 1

                if enemy_count >= 2:
                    return opposing_team

                if len(neighbors) > 0 and all(n in self.board for n in neighbors):
                    return opposing_team
        return None

def generate_moves_for_piece(state, q, r, piece):
    moves = []
    
    # --- OPTION STRATÉGIQUE : Ne pas bouger (Passer son tour) ---
    moves.append({
        'type': 'pass', 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']} garde sa position en {(q, r)}"
    })

    neighbors = state.get_neighbors(q, r)
    empty_neighbors = [n for n in neighbors if n not in state.board]
    
    has_vizir = any(p['name'] == 'Vizir' and p['team'] == piece['team'] for p in state.board.values())
    name = piece['name']
    
    # --- DÉPLACEMENT BASIQUE ---
    for n in empty_neighbors:
        moves.append({
            'type': 'move', 'from': (q, r), 'to': n, 'desc': f"Déplacer {name} en {n}"
        })
        
        if name == 'Leader' and has_vizir:
            for sn in state.get_neighbors(n[0], n[1]):
                if sn not in state.board and sn != (q, r):
                    moves.append({
                        'type': 'move', 'from': (q, r), 'to': sn, 
                        'path': [n, sn], 
                        'desc': f"Leader (boost Vizir) : {(q,r)} -> {n} -> {sn}"
                    })

    # --- VÉRIFICATION DU GEÔLIER ENNEMI ---
    is_silenced_by_geolier = False
    for n in neighbors:
        if n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'Geôlier':
            is_silenced_by_geolier = True

    if is_silenced_by_geolier:
        return moves

    # --- COMPÉTENCES ACTIVES ---
    if name == 'Cavalier':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q + dq, r + dr), (q + 2*dq, r + 2*dr)
            if state.is_valid_hex(n1[0], n1[1]) and state.is_valid_hex(n2[0], n2[1]):
                if n1 not in state.board and n2 not in state.board:
                    moves.append({'type': 'skill', 'from': (q, r), 'to': n2, 'desc': f"Cavalier charge en {n2}"})

    elif name == 'Garde Royal':
        leader_pos = next((pos for pos, p in state.board.items() if p['name'] == 'Leader' and p['team'] == piece['team']), None)
        if leader_pos:
            # Identifier les cases adjacentes au Leader pour la téléportation
            teleport_hexes = [ln for ln in state.get_neighbors(leader_pos[0], leader_pos[1]) if ln not in state.board or ln == (q, r)]
            
            for t_hex in teleport_hexes:
                # 1. Option de se téléporter et de s'arrêter là
                moves.append({
                    'type': 'skill', 
                    'from': (q, r), 
                    'to': t_hex, 
                    'desc': f"Garde Royal se téléporte près du Leader en {t_hex}"
                })
                
                # 2. Option de se téléporter PUIS de se déplacer d'une case supplémentaire
                for final_hex in state.get_neighbors(t_hex[0], t_hex[1]):
                    # La case d'arrivée doit être vide (ou correspondre à sa case de départ)
                    if (final_hex not in state.board or final_hex == (q, r)) and final_hex != t_hex:
                        moves.append({
                            'type': 'skill', 
                            'from': (q, r),
                            'path': [t_hex, final_hex], # Optionnel : garder la trace du chemin
                            'to': final_hex, 
                            'desc': f"Garde Royal se téléporte en {t_hex} puis se déplace en {final_hex}"
                        })

    elif name == 'Tavernier':
        for n in neighbors:
            if n in state.board and state.board[n]['team'] == piece['team']:
                for tn in [x for x in state.get_neighbors(n[0], n[1]) if x not in state.board and x != (q, r)]:
                    moves.append({'type': 'skill', 'from': (q, r), 'target': n, 'to': tn, 'desc': f"Tavernier déplace allié vers {tn}"})

    elif name == 'Acrobate':
        for n in state.get_neighbors(q, r):
            if n in state.board: # Il y a un obstacle
                # Calcul de la case d'atterrissage du 1er saut (tout droit)
                jump1_hex = (n[0] + (n[0] - q), n[1] + (n[1] - r))
                
                # S'il atterrit sur le plateau et que la case est vide
                if jump1_hex not in state.board and state.is_valid_hex(jump1_hex):
                    # 1ère Option : Un seul saut
                    moves.append({
                        'type': 'skill', 'from': (q, r), 'to': jump1_hex,
                        'desc': f"Acrobate saute en {jump1_hex}"
                    })
                    
                    # 2ème Option : Tenter un 2ème saut consécutif depuis jump1_hex
                    for n2 in state.get_neighbors(jump1_hex[0], jump1_hex[1]):
                        if n2 in state.board: # Un nouvel obstacle
                            jump2_hex = (n2[0] + (n2[0] - jump1_hex[0]), n2[1] + (n2[1] - jump1_hex[1]))
                            
                            # La case d'arrivée doit être vide, sur le plateau, et différente de la case de départ originelle
                            if jump2_hex not in state.board and jump2_hex != (q, r) and state.is_valid_hex(jump2_hex):
                                moves.append({
                                    'type': 'skill', 'from': (q, r), 'to': jump2_hex,
                                    'path': [jump1_hex, jump2_hex],
                                    'desc': f"Acrobate double saute via {jump1_hex} jusqu'en {jump2_hex}"
                                })

    elif name == 'Cogneur':
        for n in state.get_neighbors(q, r):
            # Si un ennemi est adjacent
            if n in state.board and state.board[n]['team'] != piece['team']:
                
                # On identifie les 3 cases opposées pour la poussée
                my_neighbors = state.get_neighbors(q, r)
                opposite_hexes = [
                    opp for opp in state.get_neighbors(n[0], n[1])
                    if opp != (q, r) and opp not in my_neighbors
                ]
                
                # On génère un mouvement pour chaque direction de poussée possible
                for push_hex in opposite_hexes:
                    if push_hex not in state.board and state.is_valid_hex(push_hex):
                        moves.append({
                            'type': 'skill',
                            'from': (q, r),
                            'to': n, # Le cogneur prend la place de l'ennemi
                            'push_target': n, # Info utile pour apply_move()
                            'push_to': push_hex,
                            'desc': f"Cogneur tape l'ennemi en {n} et le pousse en {push_hex}"
                        })

    elif name == 'Rôdeuse':
        for h in VALID_HEXES:
            if h not in state.board:
                is_adj_to_enemy = any(hn in state.board and state.board[hn]['team'] != piece['team'] for hn in state.get_neighbors(h[0], h[1]))
                if not is_adj_to_enemy:
                    moves.append({'type': 'skill', 'from': (q, r), 'to': h, 'desc': f"Rôdeuse furtive en {h}"})

    elif name == 'Lance-grappin':
        for vis in state.get_visible_pieces(q, r):
            t_pos, t_piece, (dq, dr) = vis['pos'], vis['piece'], vis['dir']
            land_q, land_r = t_pos[0] - dq, t_pos[1] - dr
            if (land_q, land_r) != (q, r) and state.is_valid_hex(land_q, land_r) and (land_q, land_r) not in state.board:
                moves.append({'type': 'skill', 'from': (q, r), 'to': (land_q, land_r), 'desc': f"Lance-grappin se hisse vers {t_pos}"})
                
            pull_q, pull_r = q + dq, r + dr
            if (pull_q, pull_r) != t_pos and state.is_valid_hex(pull_q, pull_r) and (pull_q, pull_r) not in state.board:
                can_pull = True
                if t_piece['team'] != piece['team'] and not state.can_be_moved_by_enemy_skill(t_pos, t_piece['team']):
                    can_pull = False
                if can_pull:
                    moves.append({'type': 'skill', 'from': (q, r), 'target': t_pos, 'to': (pull_q, pull_r), 'desc': f"Lance-grappin attire {t_piece['name']} en {(pull_q, pull_r)}"})

    elif name == 'Illusionniste':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1:
                moves.append({'type': 'swap', 'from': (q, r), 'to': vis['pos'], 'desc': f"Illusionniste swap avec {vis['piece']['name']} en {vis['pos']}"})

    elif name == 'Manipulatrice':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1 and vis['piece']['team'] != piece['team']:
                t_pos = vis['pos']
                if state.can_be_moved_by_enemy_skill(t_pos, vis['piece']['team']):
                    for tn in state.get_neighbors(t_pos[0], t_pos[1]):
                        if tn not in state.board:
                            moves.append({'type': 'skill', 'from': (q, r), 'target': t_pos, 'to': tn, 'desc': f"Manipulatrice déplace l'ennemi vers {tn}"})

    return moves

def apply_move(state, move):
    new_state = copy.deepcopy(state)
    
    if move['type'] == 'pass':
        return new_state

    if move['type'] == 'swap':
        p1, p2 = new_state.board.pop(move['from']), new_state.board.pop(move['to'])
        new_state.board[move['to']], new_state.board[move['from']] = p1, p2
        return new_state

    # Repérage préalable pour voir si le Leader adverse change de case
    moving_piece = new_state.board.get(move['from'])
    moving_team = moving_piece['team'] if moving_piece else None
    opposing_team = 'enemy' if moving_team == 'ally' else 'ally'
    
    leader_pos_before = next((pos for pos, p in new_state.board.items() if p['name'] == 'Leader' and p['team'] == opposing_team), None)

    piece = new_state.board.pop(move['from'])
    
    if 'target' in move and 'target_to' not in move:
        target_piece = new_state.board.pop(move['target'])
        new_state.board[move['to']] = target_piece
        new_state.board[move['from']] = piece
    elif 'push_target' in move:
        # On récupère l'ennemi avant qu'il ne soit écrasé
        target_piece = new_state.board.pop(move['push_target'])
        # On le place sur sa case de réception
        new_state.board[move['push_to']] = target_piece
        # Le Cogneur prend la place initiale de l'ennemi
        new_state.board[move['to']] = piece
    elif 'target_to' in move:
        target_piece = new_state.board.pop(move['to'])
        new_state.board[move['target_to']] = target_piece
        new_state.board[move['to']] = piece
    else:
        new_state.board[move['to']] = piece
        

    # Vérification post-action si le Leader adverse a changé de case
    leader_pos_after = next((pos for pos, p in new_state.board.items() if p['name'] == 'Leader' and p['team'] == opposing_team), None)
    
    if leader_pos_before and leader_pos_after and leader_pos_before != leader_pos_after:
        # Déclenchement automatique de la Némésis de l'équipe adverse si elle existe
        nemesis_pos = next((pos for pos, p in new_state.board.items() if p['name'] == 'Némésis' and p['team'] == opposing_team), None)
        if nemesis_pos:
            # La Némésis doit obligatoirement bouger de 2 cases en 2 étapes sans revenir sur sa case de départ
            n_piece = new_state.board.pop(nemesis_pos)
            step1_options = [n for n in new_state.get_neighbors(nemesis_pos[0], nemesis_pos[1]) if n not in new_state.board]
            if step1_options:
                # On choisit le premier pas valide (le moteur pourra explorer d'autres branches si on l'intègre finement dans l'arbre)
                step1 = step1_options[0]
                step2_options = [n for n in new_state.get_neighbors(step1[0], step1[1]) if n not in new_state.board and n != nemesis_pos]
                if step2_options:
                    final_step = step2_options[0]
                    new_state.board[final_step] = n_piece
                else:
                    new_state.board[step1] = n_piece # Repli sur 1 pas si le 2ème est bloqué
            else:
                new_state.board[nemesis_pos] = n_piece # Si totalement bloqué

    return new_state

