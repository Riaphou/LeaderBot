import time

# --- MOTEUR DE TRADUCTION DES COORDONNÉES ---

def to_user_coords(q, r):
    return q, r

def from_user_coords(q_user, r_user):
    return q_user, r_user

def fmt(pos):
    """Formate un tuple de position interne pour l'affichage texte."""
    return str(to_user_coords(pos[0], pos[1]))


# --- MOTEUR DE RÈGLES ---

DIRECTIONS = [
    (0, 1), (-1, 1), (1, 0), (1, -1), (0, -1), (-1, 0)
]

VALID_HEXES = set()
VALID_HEXES.update([(1, r) for r in range(4, 8)])
VALID_HEXES.update([(2, r) for r in range(3, 8)])
VALID_HEXES.update([(3, r) for r in range(2, 8)])
VALID_HEXES.update([(4, r) for r in range(1, 8)])
VALID_HEXES.update([(5, r) for r in range(1, 7)])
VALID_HEXES.update([(6, r) for r in range(1, 6)])
VALID_HEXES.update([(7, r) for r in range(1, 5)])

def hex_distance(q1, r1, q2, r2):
    return (abs(q1 - q2) + abs(q1 + r1 - q2 - r2) + abs(r1 - r2)) // 2

class GameState:
    def __init__(self):
        self.board = {}
        self.current_team = 'ally'
        self.pieces_moved_this_turn = set()

    def state_hash(self):
        """Génère un identifiant unique (hash) ultra-rapide pour la table de transposition."""
        board_tuple = frozenset((pos, p['name'], p['team']) for pos, p in self.board.items())
        moved_tuple = frozenset(self.pieces_moved_this_turn)
        return hash((board_tuple, self.current_team, moved_tuple))

    def is_valid_hex(self, q, r):
        return (q, r) in VALID_HEXES

    def get_neighbors(self, q, r):
        return [(q+dq, r+dr) for dq, dr in DIRECTIONS if self.is_valid_hex(q+dq, r+dr)]

    def get_visible_pieces(self, q, r):
        visible = []
        for dq, dr in DIRECTIONS:
            cq, cr = q + dq, r + dr
            dist = 1
            while self.is_valid_hex(cq, cr):
                if (cq, cr) in self.board:
                    visible.append({
                        'pos': (cq, cr), 
                        'piece': self.board[(cq, cr)], 
                        'dir': (dq, dr), 
                        'dist': dist
                    })
                    break
                cq += dq
                cr += dr
                dist += 1
        return visible

    def can_be_moved_by_enemy_skill(self, pos, team):
        if self.board[pos]['name'] == 'pro':
            return False
        for n in self.get_neighbors(pos[0], pos[1]):
            if n in self.board and self.board[n]['team'] == team and self.board[n]['name'] == 'pro':
                return False
        return True

    def check_victory(self):
        for (q, r), piece in self.board.items():
            if piece['name'] == 'lea':
                team = piece['team']
                opposing_team = 'enemy' if team == 'ally' else 'ally'
                
                neighbors = self.get_neighbors(q, r)
                
                enemy_count = 0
                for n in neighbors:
                    if n in self.board and self.board[n]['team'] == opposing_team:
                        enemy_count += 1
                        if self.board[n]['name'] == 'ass':
                            enemy_count += 10
                        if self.board[n]['name'] in ['our', 'arc']:
                            enemy_count -= 1
                
                for vis in self.get_visible_pieces(q, r):
                    if vis['dist'] == 2 and vis['piece']['team'] == opposing_team and vis['piece']['name'] == 'arc':
                        enemy_count += 1

                if enemy_count >= 2:
                    return opposing_team

                if len(neighbors) > 0 and all(n in self.board for n in neighbors):
                    return opposing_team
        return None

    def make_move(self, move):
        """Applique un coup de manière réversible et retourne les infos nécessaires pour l'annuler."""
        undo_info = {
            'old_team': self.current_team,
            'old_moved': set(self.pieces_moved_this_turn),
            'board_restore': {}
        }
        
        # Sauvegarder uniquement les cases qui vont être modifiées (remplace le deepcopy coûteux)
        squares_to_touch = set()
        if move['type'] == 'swap':
            squares_to_touch.update([move['from'], move['to']])
        elif move['type'] != 'pass':
            squares_to_touch.update([move['from'], move['to']])
            if 'push_target' in move: squares_to_touch.update([move['push_target'], move['push_to']])
            if 'target' in move: squares_to_touch.add(move['target'])
            
        for sq in squares_to_touch:
            undo_info['board_restore'][sq] = self.board.get(sq) # None si la case est vide

        # Application du coup
        if move['type'] == 'swap':
            p1, p2 = self.board.pop(move['from']), self.board.pop(move['to'])
            self.board[move['to']], self.board[move['from']] = p1, p2
        elif move['type'] != 'pass':
            piece = self.board.pop(move['from'])
            if 'push_target' in move:
                self.board[move['push_to']] = self.board.pop(move['push_target'])
                self.board[move['to']] = piece
            elif 'target' in move:
                self.board[move['to']] = self.board.pop(move['target'])
                self.board[move['from']] = piece
            else:
                self.board[move['to']] = piece
                
        if move['type'] != 'pass' or move['type'] == 'pass': 
            self.pieces_moved_this_turn.add(move['to'])

        ally_count = sum(1 for p in self.board.values() if p['team'] == self.current_team)
        if len(self.pieces_moved_this_turn) >= ally_count:
            self.current_team = 'enemy' if self.current_team == 'ally' else 'ally'
            self.pieces_moved_this_turn.clear()

        return undo_info

    def unmake_move(self, undo_info):
        """Restaure le plateau dans son état exact avant le coup."""
        self.current_team = undo_info['old_team']
        self.pieces_moved_this_turn = undo_info['old_moved']
        for sq, piece in undo_info['board_restore'].items():
            if piece is None:
                self.board.pop(sq, None)
            else:
                self.board[sq] = piece


def generate_moves_for_piece(state, q, r, piece):
    moves = []
    
    moves.append({'type': 'pass', 'team': piece['team'], 'from': (q, r), 'to': (q, r), 'desc': f"{piece['name']} maintient sa position en {fmt((q, r))})"})

    neighbors = state.get_neighbors(q, r)
    empty_neighbors = [n for n in neighbors if n not in state.board]
    has_viz = any(p['name'] == 'viz' and p['team'] == piece['team'] for p in state.board.values())
    name = piece['name']
    
    for n in empty_neighbors:
        moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': n, 'desc': f"{name} avance furtivement en {fmt(n)}"})
        if name == 'lea' and has_viz:
            for sn in state.get_neighbors(n[0], n[1]):
                if sn not in state.board and sn != (q, r):
                    moves.append({'type': 'move', 'team': piece['team'], 'from': (q, r), 'to': sn, 'desc': f"lea (Porté par les vents du viz) bondit vers {fmt(sn)}"})

    if any(n in state.board and state.board[n]['team'] != piece['team'] and state.board[n]['name'] == 'geo' for n in neighbors):
        return moves

    if name == 'cav':
        for dq, dr in DIRECTIONS:
            n1, n2 = (q + dq, r + dr), (q + 2*dq, r + 2*dr)
            if state.is_valid_hex(n1[0], n1[1]) and state.is_valid_hex(n2[0], n2[1]) and n1 not in state.board and n2 not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n2, 'desc': f"cav charge violemment en {fmt(n2)}"})

    elif name == 'gar':
        lea_pos = next((pos for pos, p in state.board.items() if p['name'] == 'lea' and p['team'] == piece['team']), None)
        if lea_pos:
            teleport_hexes = [ln for ln in state.get_neighbors(lea_pos[0], lea_pos[1]) if ln not in state.board or ln == (q, r)]
            for t_hex in teleport_hexes:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': t_hex, 'desc': f"gar se téléporte pour protéger le lea en {fmt(t_hex)}"})
                for final_hex in state.get_neighbors(t_hex[0], t_hex[1]):
                    if (final_hex not in state.board or final_hex == (q, r)) and final_hex != t_hex:
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': final_hex, 'desc': f"gar se déploie en {fmt(final_hex)} après téléportation"})

    elif name == 'tav':
        for n in neighbors:
            if n in state.board and state.board[n]['team'] == piece['team']:
                for tn in [x for x in state.get_neighbors(n[0], n[1]) if x not in state.board and x != (q, r)]:
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'target': n, 'to': tn, 'desc': f"tav bouscule amicalement l'allié en {fmt(n)} vers {fmt(tn)}"})

    elif name == 'acr':
        for n in state.get_neighbors(q, r):
            if n in state.board:
                jump1 = (n[0] + (n[0] - q), n[1] + (n[1] - r))
                if jump1 not in state.board and state.is_valid_hex(jump1[0], jump1[1]):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': jump1, 'desc': f"acr voltige par-dessus l'obstacle jusqu'en {fmt(jump1)}"})

    elif name == 'cog':
        for n in state.get_neighbors(q, r):
            if n in state.board and state.board[n]['team'] != piece['team']:
                my_neighbors = state.get_neighbors(q, r)
                opposite_hexes = [opp for opp in state.get_neighbors(n[0], n[1]) if opp != (q, r) and opp not in my_neighbors]
                for push_hex in opposite_hexes:
                    if push_hex not in state.board and state.is_valid_hex(push_hex[0], push_hex[1]):
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': n, 'push_target': n, 'push_to': push_hex, 'desc': f"cog fracasse l'ennemi vers {fmt(push_hex)} et prend sa place en {fmt(n)}"})

    elif name == 'rod':
        for h in VALID_HEXES:
            if h not in state.board:
                if not any(hn in state.board and state.board[hn]['team'] != piece['team'] for hn in state.get_neighbors(h[0], h[1])):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': h, 'desc': f"rod se fond dans les ombres et réapparait en {fmt(h)}"})

    elif name == 'lan':
        for vis in state.get_visible_pieces(q, r):
            t_pos, t_piece, (dq, dr) = vis['pos'], vis['piece'], vis['dir']
            land_q, land_r = t_pos[0] - dq, t_pos[1] - dr
            if (land_q, land_r) != (q, r) and state.is_valid_hex(land_q, land_r) and (land_q, land_r) not in state.board:
                moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'to': (land_q, land_r), 'desc': f"lan se tracte tel un prédateur vers {fmt(t_pos)}"})
            pull_q, pull_r = q + dq, r + dr
            if (pull_q, pull_r) != t_pos and state.is_valid_hex(pull_q, pull_r) and (pull_q, pull_r) not in state.board:
                if t_piece['team'] == piece['team'] or state.can_be_moved_by_enemy_skill(t_pos, t_piece['team']):
                    moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'target': t_pos, 'to': (pull_q, pull_r), 'desc': f"lan ferre {t_piece['name']} et le ramène en {fmt((pull_q, pull_r))}"})

    elif name == 'ill':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1:
                moves.append({'type': 'swap', 'team': piece['team'], 'from': (q, r), 'to': vis['pos'], 'desc': f"ill altère la réalité et échange de place avec {vis['piece']['name']} en {fmt(vis['pos'])}"})

    elif name == 'man':
        for vis in state.get_visible_pieces(q, r):
            if vis['dist'] > 1 and vis['piece']['team'] != piece['team'] and state.can_be_moved_by_enemy_skill(vis['pos'], vis['piece']['team']):
                for tn in state.get_neighbors(vis['pos'][0], vis['pos'][1]):
                    if tn not in state.board:
                        moves.append({'type': 'skill', 'team': piece['team'], 'from': (q, r), 'target': vis['pos'], 'to': tn, 'desc': f"man force l'esprit de l'ennemi à marcher vers {fmt(tn)}"})

    return moves


# --- MOTEUR DE RECHERCHE OPTIMISÉ (ALPHA-BETA + TRANSPOSITION) ---

class SearchEngine:
    def __init__(self):
        self.tt = {} # Table de transposition
        self.nodes_explored = 0
        self.tt_hits = 0

    def sort_moves_heuristically(self, state, moves, maximizing_player):
        target_team = 'enemy' if maximizing_player else 'ally'
        lea_pos = next((pos for pos, p in state.board.items() if p['name'] == 'lea' and p['team'] == target_team), None)
        
        if not lea_pos:
            return moves

        def move_score(move):
            if move['type'] == 'pass': return 999 
            main_to_pos = move.get('push_to') or move['to']
            return hex_distance(main_to_pos[0], main_to_pos[1], lea_pos[0], lea_pos[1])

        return sorted(moves, key=move_score)

    def get_all_possible_moves(self, state, team):
        all_moves = []
        for pos, piece in state.board.items():
            if piece['team'] == team and pos not in state.pieces_moved_this_turn:
                all_moves.extend(generate_moves_for_piece(state, pos[0], pos[1], piece))
        return all_moves

    def find_winning_sequence(self, state, depth, alpha, beta, maximizing_player):
        self.nodes_explored += 1
        
        # Vérification TT (Transposition Table)
        state_h = state.state_hash()
        if state_h in self.tt:
            tt_depth, tt_score, tt_seq = self.tt[state_h]
            if tt_depth >= depth:
                self.tt_hits += 1
                return tt_score, list(tt_seq)

        # Vérification des conditions de victoire
        winner = state.check_victory()
        if winner == 'ally':
            return 100 + depth, []
        elif winner == 'enemy':
            return -100 - depth, []
        if depth == 0:
            return 0, []

        current_team = 'ally' if maximizing_player else 'enemy'
        moves = self.get_all_possible_moves(state, current_team)
        moves = self.sort_moves_heuristically(state, moves, maximizing_player)

        best_sequence = []
        
        if maximizing_player:
            max_eval = -float('inf')
            for move in moves:
                undo_info = state.make_move(move)
                next_is_max = (state.current_team == 'ally')
                
                eval_score, seq = self.find_winning_sequence(state, depth - 1, alpha, beta, next_is_max)
                state.unmake_move(undo_info) # Remplace le deepcopy
                
                if eval_score > max_eval:
                    max_eval = eval_score
                    best_sequence = [move] + seq
                    
                alpha = max(alpha, eval_score)
                if beta <= alpha or max_eval >= 100:
                    break # Élagage Alpha-Beta
            self.tt[state_h] = (depth, max_eval, best_sequence)
            return max_eval, best_sequence
        else:
            min_eval = float('inf')
            for move in moves:
                undo_info = state.make_move(move)
                next_is_max = (state.current_team == 'ally')
                
                eval_score, seq = self.find_winning_sequence(state, depth - 1, alpha, beta, next_is_max)
                state.unmake_move(undo_info)
                
                if eval_score < min_eval:
                    min_eval = eval_score
                    best_sequence = [move] + seq
                    
                beta = min(beta, eval_score)
                if beta <= alpha or min_eval <= -100:
                    break # Élagage Alpha-Beta
            self.tt[state_h] = (depth, min_eval, best_sequence)
            return min_eval, best_sequence


# --- INTERFACE UTILISATEUR & CLI ---

def parse_input(prompt_text, team):
    print(f"\n--- {prompt_text} ---")
    print("Entrez les pions un par un sous la forme 'Colonne.Ligne.Nom' (q.r.nom). Tapez 'fin' pour terminer.")
    pieces = []
    while True:
        user_input = input(f"[{team.upper()}] Pion > ").strip()
        if user_input.lower() == 'fin':
            break
        try:
            parts = user_input.split('.')
            q_user, r_user, name = int(parts[0]), int(parts[1]), parts[2].strip()
            q, r = from_user_coords(q_user, r_user)
            pieces.append(((q, r), {'name': name, 'team': team}))
        except Exception:
            print("Erreur de format. Utilisez 'q.r.Nom' (ex: 1.1.arc).")
    return pieces

def main():
    print("=====================================================")
    print(" MOTEUR V2.0 - ARCHITECTURE OPTIMISÉE (TT, ALPHA-BETA) ")
    print("=====================================================")
    
    enemies = parse_input("POSITIONS ENNEMIES", "enemy")
    allies = parse_input("POSITIONS ALLIÉES", "ally")

    while True:
        try:
            add_depth = int(input("\nProfondeur tactique max de départ (ex: 10) > "))
            break
        except ValueError:
            print("Veuillez entrer un nombre entier.")
            
    max_depth = 0
    score = 0
    
    while score < 100:
        max_depth += add_depth
        print(f"\n[Simulation de {max_depth} actions successives...]")

        state = GameState()
        for pos, p in enemies + allies:
            state.board[pos] = p
            
        engine = SearchEngine()
        start_time = time.time()
        
        # Lancement de la recherche avec Alpha-Beta
        score, sequence = engine.find_winning_sequence(state, max_depth, -float('inf'), float('inf'), maximizing_player=True)
        
        end_time = time.time()

        print("\n================= STATISTIQUES ===================")
        print(f"Nœuds explorés       : {engine.nodes_explored}")
        print(f"Coups en cache (TT)  : {engine.tt_hits}")
        print(f"Temps de calcul      : {end_time - start_time:.3f} secondes")
        print("==================================================")
        
        print("\n================ RAPPORT DE BATAILLE ===============")
        if score >= 100:
            print("VICTOIRE TOTALE GARANTIE ! Ligne principale forcée :\n")
            for i, move in enumerate(sequence):
                step_team = "Vos Forces" if move.get('team') == 'ally' else "Riposte Ennemie"
                print(f"[{step_team}] Étape {i+1} : {move['desc']}")
            break # Sort de la boucle car la victoire est assurée
        elif score <= -100:
            print("ALERTE CRITIQUE : Défaite forcée détectée. Augmentez la profondeur ou modifiez la position initiale.")
            break
        else:
            print(f"Aucune victoire forcée trouvée dans les {max_depth} prochains mouvements.")
            if sequence:
                print(f"Meilleure manœuvre d'ouverture suggérée : {sequence[0]['desc']}")
                
        print("====================================================")

if __name__ == "__main__":
    main()